/*
 * iMatrix.cpp
 *
 *  Created on: Jul 24, 2024
 *      Author: ienebuse
 */

#include <eMatrix.h>

//eMatrix::eMatrix()
//{
//    // TODO Auto-generated constructor stub
//
//}
//
//eMatrix::~eMatrix()
//{
//    // TODO Auto-generated destructor stub
//}

//float determinant3x3(float **A) {
//    return A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1]) -
//           A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0]) +
//           A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]);
//}

#define SIZE  6
#define EPSILON 1e-9  // Tolerance for detecting singularity

void adjugate3x3(float A[10][10], float adjA[3][3]) {
    adjA[0][0] = (A[1][1] * A[2][2] - A[1][2] * A[2][1]);
    adjA[0][1] = -(A[1][0] * A[2][2] - A[1][2] * A[2][0]);
    adjA[0][2] = (A[1][0] * A[2][1] - A[1][1] * A[2][0]);

    adjA[1][0] = -(A[0][1] * A[2][2] - A[0][2] * A[2][1]);
    adjA[1][1] = (A[0][0] * A[2][2] - A[0][2] * A[2][0]);
    adjA[1][2] = -(A[0][0] * A[2][1] - A[0][1] * A[2][0]);

    adjA[2][0] = (A[0][1] * A[1][2] - A[0][2] * A[1][1]);
    adjA[2][1] = -(A[0][0] * A[1][2] - A[0][2] * A[1][0]);
    adjA[2][2] = (A[0][0] * A[1][1] - A[0][1] * A[1][0]);
}


void eMatrix::mat3x3Inverse(float arrIn[10][10], float arrOut[10][10]) {
//	float det = determinant3x3(arrIn);

	float det = arrIn[0][0] * (arrIn[1][1] * arrIn[2][2] - arrIn[1][2] * arrIn[2][1]) -
	           arrIn[0][1] * (arrIn[1][0] * arrIn[2][2] - arrIn[1][2] * arrIn[2][0]) +
	           arrIn[0][2] * (arrIn[1][0] * arrIn[2][1] - arrIn[1][1] * arrIn[2][0]);

    float invDet = 1.0 / det;
    float adjA[3][3];
    adjugate3x3(arrIn, adjA);

    for (int i = 0; i < 3; ++i) {
        for (int j = 0; j < 3; ++j) {
        	arrOut[i][j] = adjA[i][j] * invDet;
        }
    }

}

void getCofactor6(float mat[SIZE][SIZE], float temp[SIZE][SIZE], int p, int q, int n) {
    int i = 0, j = 0;

    for (int row = 0; row < n; row++) {
        for (int col = 0; col < n; col++) {
            if (row != p && col != q) {
                temp[i][j++] = mat[row][col];
                if (j == n - 1) {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

void getCofactor7(float mat[10][10], float temp[SIZE][SIZE], int p, int q, int n) {
    int i = 0, j = 0;

    for (int row = 0; row < n; row++) {
        for (int col = 0; col < n; col++) {
            if (row != p && col != q) {
                temp[i][j++] = mat[row][col];
                if (j == n - 1) {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

float determinant6(float mat[SIZE][SIZE], int n) {
    float D = 0;

    if (n == 1)
        return mat[0][0];

    float temp[SIZE][SIZE];

    int sign = 1;

    for (int f = 0; f < n; f++) {
        getCofactor6(mat, temp, 0, f, n);
        D += sign * mat[0][f] * determinant6(temp, n - 1);
        sign = -sign;
    }

    return D;
}

float determinant7(float mat[10][10], int n) {
    float D = 0;

    if (n == 1)
        return mat[0][0];

    float temp[SIZE][SIZE];

    int sign = 1;

    for (int f = 0; f < n; f++) {
        getCofactor7(mat, temp, 0, f, n);
        D += sign * mat[0][f] * determinant6(temp, n - 1);
        sign = -sign;
    }

    return D;
}



void adjoint(float mat[10][10], float adj[SIZE][SIZE]) {
    if (SIZE == 1) {
        adj[0][0] = 1;
        return;
    }

    int sign = 1;
    float temp[SIZE][SIZE];

    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            getCofactor7(mat, temp, i, j, SIZE);
            sign = ((i + j) % 2 == 0) ? 1 : -1;
            adj[j][i] = (sign) * (determinant6(temp, SIZE - 1));
        }
    }
}

void eMatrix:: matNxNInverse(float mat[10][10], float inverse[10][10]) {
    float det = determinant7(mat, SIZE);
//    if (det == 0) {
//        printf("Singular matrix, can't find its inverse");
//        return 0;
//    }

    float adj[SIZE][SIZE];
    adjoint(mat, adj);

    for (int i = 0; i < SIZE; i++){
        for (int j = 0; j < SIZE; j++) {
            inverse[i][j] = adj[i][j] / det;
        }
    }
}

void eMatrix::mat6x6Inverse(Mat* m, Mat* out) {

    double A4545 = m->m44 * m->m55 - m->m45 * m->m54 ;
    double A3545 = m->m43 * m->m55 - m->m45 * m->m53 ;
    double A3445 = m->m43 * m->m54 - m->m44 * m->m53 ;
    double A2545 = m->m42 * m->m55 - m->m45 * m->m52 ;
    double A2445 = m->m42 * m->m54 - m->m44 * m->m52 ;
    double A2345 = m->m42 * m->m53 - m->m43 * m->m52 ;
    double A1545 = m->m41 * m->m55 - m->m45 * m->m51 ;
    double A1445 = m->m41 * m->m54 - m->m44 * m->m51 ;
    double A1345 = m->m41 * m->m53 - m->m43 * m->m51 ;
    double A1245 = m->m41 * m->m52 - m->m42 * m->m51 ;
    double A0545 = m->m40 * m->m55 - m->m45 * m->m50 ;
    double A0445 = m->m40 * m->m54 - m->m44 * m->m50 ;
    double A0345 = m->m40 * m->m53 - m->m43 * m->m50 ;
    double A0245 = m->m40 * m->m52 - m->m42 * m->m50 ;
    double A0145 = m->m40 * m->m51 - m->m41 * m->m50 ;
    double A4535 = m->m34 * m->m55 - m->m35 * m->m54 ;
    double A3535 = m->m33 * m->m55 - m->m35 * m->m53 ;
    double A3435 = m->m33 * m->m54 - m->m34 * m->m53 ;
    double A2535 = m->m32 * m->m55 - m->m35 * m->m52 ;
    double A2435 = m->m32 * m->m54 - m->m34 * m->m52 ;
    double A2335 = m->m32 * m->m53 - m->m33 * m->m52 ;
    double A1535 = m->m31 * m->m55 - m->m35 * m->m51 ;
    double A1435 = m->m31 * m->m54 - m->m34 * m->m51 ;
    double A1335 = m->m31 * m->m53 - m->m33 * m->m51 ;
    double A1235 = m->m31 * m->m52 - m->m32 * m->m51 ;
    double A4534 = m->m34 * m->m45 - m->m35 * m->m44 ;
    double A3534 = m->m33 * m->m45 - m->m35 * m->m43 ;
    double A3434 = m->m33 * m->m44 - m->m34 * m->m43 ;
    double A2534 = m->m32 * m->m45 - m->m35 * m->m42 ;
    double A2434 = m->m32 * m->m44 - m->m34 * m->m42 ;
    double A2334 = m->m32 * m->m43 - m->m33 * m->m42 ;
    double A1534 = m->m31 * m->m45 - m->m35 * m->m41 ;
    double A1434 = m->m31 * m->m44 - m->m34 * m->m41 ;
    double A1334 = m->m31 * m->m43 - m->m33 * m->m41 ;
    double A1234 = m->m31 * m->m42 - m->m32 * m->m41 ;
    double A0535 = m->m30 * m->m55 - m->m35 * m->m50 ;
    double A0435 = m->m30 * m->m54 - m->m34 * m->m50 ;
    double A0335 = m->m30 * m->m53 - m->m33 * m->m50 ;
    double A0235 = m->m30 * m->m52 - m->m32 * m->m50 ;
    double A0534 = m->m30 * m->m45 - m->m35 * m->m40 ;
    double A0434 = m->m30 * m->m44 - m->m34 * m->m40 ;
    double A0334 = m->m30 * m->m43 - m->m33 * m->m40 ;
    double A0234 = m->m30 * m->m42 - m->m32 * m->m40 ;
    double A0135 = m->m30 * m->m51 - m->m31 * m->m50 ;
    double A0134 = m->m30 * m->m41 - m->m31 * m->m40 ;

    double B345345 = m->m33 * A4545 - m->m34 * A3545 + m->m35 * A3445 ;
    double B245345 = m->m32 * A4545 - m->m34 * A2545 + m->m35 * A2445 ;
    double B235345 = m->m32 * A3545 - m->m33 * A2545 + m->m35 * A2345 ;
    double B234345 = m->m32 * A3445 - m->m33 * A2445 + m->m34 * A2345 ;
    double B145345 = m->m31 * A4545 - m->m34 * A1545 + m->m35 * A1445 ;
    double B135345 = m->m31 * A3545 - m->m33 * A1545 + m->m35 * A1345 ;
    double B134345 = m->m31 * A3445 - m->m33 * A1445 + m->m34 * A1345 ;
    double B125345 = m->m31 * A2545 - m->m32 * A1545 + m->m35 * A1245 ;
    double B124345 = m->m31 * A2445 - m->m32 * A1445 + m->m34 * A1245 ;
    double B123345 = m->m31 * A2345 - m->m32 * A1345 + m->m33 * A1245 ;
    double B045345 = m->m30 * A4545 - m->m34 * A0545 + m->m35 * A0445 ;
    double B035345 = m->m30 * A3545 - m->m33 * A0545 + m->m35 * A0345 ;
    double B034345 = m->m30 * A3445 - m->m33 * A0445 + m->m34 * A0345 ;
    double B025345 = m->m30 * A2545 - m->m32 * A0545 + m->m35 * A0245 ;
    double B024345 = m->m30 * A2445 - m->m32 * A0445 + m->m34 * A0245 ;
    double B023345 = m->m30 * A2345 - m->m32 * A0345 + m->m33 * A0245 ;
    double B015345 = m->m30 * A1545 - m->m31 * A0545 + m->m35 * A0145 ;
    double B014345 = m->m30 * A1445 - m->m31 * A0445 + m->m34 * A0145 ;
    double B013345 = m->m30 * A1345 - m->m31 * A0345 + m->m33 * A0145 ;
    double B012345 = m->m30 * A1245 - m->m31 * A0245 + m->m32 * A0145 ;
    double B345245 = m->m23 * A4545 - m->m24 * A3545 + m->m25 * A3445 ;
    double B245245 = m->m22 * A4545 - m->m24 * A2545 + m->m25 * A2445 ;
    double B235245 = m->m22 * A3545 - m->m23 * A2545 + m->m25 * A2345 ;
    double B234245 = m->m22 * A3445 - m->m23 * A2445 + m->m24 * A2345 ;
    double B145245 = m->m21 * A4545 - m->m24 * A1545 + m->m25 * A1445 ;
    double B135245 = m->m21 * A3545 - m->m23 * A1545 + m->m25 * A1345 ;
    double B134245 = m->m21 * A3445 - m->m23 * A1445 + m->m24 * A1345 ;
    double B125245 = m->m21 * A2545 - m->m22 * A1545 + m->m25 * A1245 ;
    double B124245 = m->m21 * A2445 - m->m22 * A1445 + m->m24 * A1245 ;
    double B123245 = m->m21 * A2345 - m->m22 * A1345 + m->m23 * A1245 ;
    double B345235 = m->m23 * A4535 - m->m24 * A3535 + m->m25 * A3435 ;
    double B245235 = m->m22 * A4535 - m->m24 * A2535 + m->m25 * A2435 ;
    double B235235 = m->m22 * A3535 - m->m23 * A2535 + m->m25 * A2335 ;
    double B234235 = m->m22 * A3435 - m->m23 * A2435 + m->m24 * A2335 ;
    double B145235 = m->m21 * A4535 - m->m24 * A1535 + m->m25 * A1435 ;
    double B135235 = m->m21 * A3535 - m->m23 * A1535 + m->m25 * A1335 ;
    double B134235 = m->m21 * A3435 - m->m23 * A1435 + m->m24 * A1335 ;
    double B125235 = m->m21 * A2535 - m->m22 * A1535 + m->m25 * A1235 ;
    double B124235 = m->m21 * A2435 - m->m22 * A1435 + m->m24 * A1235 ;
    double B123235 = m->m21 * A2335 - m->m22 * A1335 + m->m23 * A1235 ;
    double B345234 = m->m23 * A4534 - m->m24 * A3534 + m->m25 * A3434 ;
    double B245234 = m->m22 * A4534 - m->m24 * A2534 + m->m25 * A2434 ;
    double B235234 = m->m22 * A3534 - m->m23 * A2534 + m->m25 * A2334 ;
    double B234234 = m->m22 * A3434 - m->m23 * A2434 + m->m24 * A2334 ;
    double B145234 = m->m21 * A4534 - m->m24 * A1534 + m->m25 * A1434 ;
    double B135234 = m->m21 * A3534 - m->m23 * A1534 + m->m25 * A1334 ;
    double B134234 = m->m21 * A3434 - m->m23 * A1434 + m->m24 * A1334 ;
    double B125234 = m->m21 * A2534 - m->m22 * A1534 + m->m25 * A1234 ;
    double B124234 = m->m21 * A2434 - m->m22 * A1434 + m->m24 * A1234 ;
    double B123234 = m->m21 * A2334 - m->m22 * A1334 + m->m23 * A1234 ;
    double B045245 = m->m20 * A4545 - m->m24 * A0545 + m->m25 * A0445 ;
    double B035245 = m->m20 * A3545 - m->m23 * A0545 + m->m25 * A0345 ;
    double B034245 = m->m20 * A3445 - m->m23 * A0445 + m->m24 * A0345 ;
    double B025245 = m->m20 * A2545 - m->m22 * A0545 + m->m25 * A0245 ;
    double B024245 = m->m20 * A2445 - m->m22 * A0445 + m->m24 * A0245 ;
    double B023245 = m->m20 * A2345 - m->m22 * A0345 + m->m23 * A0245 ;
    double B045235 = m->m20 * A4535 - m->m24 * A0535 + m->m25 * A0435 ;
    double B035235 = m->m20 * A3535 - m->m23 * A0535 + m->m25 * A0335 ;
    double B034235 = m->m20 * A3435 - m->m23 * A0435 + m->m24 * A0335 ;
    double B025235 = m->m20 * A2535 - m->m22 * A0535 + m->m25 * A0235 ;
    double B024235 = m->m20 * A2435 - m->m22 * A0435 + m->m24 * A0235 ;
    double B023235 = m->m20 * A2335 - m->m22 * A0335 + m->m23 * A0235 ;
    double B045234 = m->m20 * A4534 - m->m24 * A0534 + m->m25 * A0434 ;
    double B035234 = m->m20 * A3534 - m->m23 * A0534 + m->m25 * A0334 ;
    double B034234 = m->m20 * A3434 - m->m23 * A0434 + m->m24 * A0334 ;
    double B025234 = m->m20 * A2534 - m->m22 * A0534 + m->m25 * A0234 ;
    double B024234 = m->m20 * A2434 - m->m22 * A0434 + m->m24 * A0234 ;
    double B023234 = m->m20 * A2334 - m->m22 * A0334 + m->m23 * A0234 ;
    double B015245 = m->m20 * A1545 - m->m21 * A0545 + m->m25 * A0145 ;
    double B014245 = m->m20 * A1445 - m->m21 * A0445 + m->m24 * A0145 ;
    double B013245 = m->m20 * A1345 - m->m21 * A0345 + m->m23 * A0145 ;
    double B015235 = m->m20 * A1535 - m->m21 * A0535 + m->m25 * A0135 ;
    double B014235 = m->m20 * A1435 - m->m21 * A0435 + m->m24 * A0135 ;
    double B013235 = m->m20 * A1335 - m->m21 * A0335 + m->m23 * A0135 ;
    double B015234 = m->m20 * A1534 - m->m21 * A0534 + m->m25 * A0134 ;
    double B014234 = m->m20 * A1434 - m->m21 * A0434 + m->m24 * A0134 ;
    double B013234 = m->m20 * A1334 - m->m21 * A0334 + m->m23 * A0134 ;
    double B012245 = m->m20 * A1245 - m->m21 * A0245 + m->m22 * A0145 ;
    double B012235 = m->m20 * A1235 - m->m21 * A0235 + m->m22 * A0135 ;
    double B012234 = m->m20 * A1234 - m->m21 * A0234 + m->m22 * A0134 ;

    double C23452345 = m->m22 * B345345 - m->m23 * B245345 + m->m24 * B235345 - m->m25 * B234345 ;
    double C13452345 = m->m21 * B345345 - m->m23 * B145345 + m->m24 * B135345 - m->m25 * B134345 ;
    double C12452345 = m->m21 * B245345 - m->m22 * B145345 + m->m24 * B125345 - m->m25 * B124345 ;
    double C12352345 = m->m21 * B235345 - m->m22 * B135345 + m->m23 * B125345 - m->m25 * B123345 ;
    double C12342345 = m->m21 * B234345 - m->m22 * B134345 + m->m23 * B124345 - m->m24 * B123345 ;
    double C03452345 = m->m20 * B345345 - m->m23 * B045345 + m->m24 * B035345 - m->m25 * B034345 ;
    double C02452345 = m->m20 * B245345 - m->m22 * B045345 + m->m24 * B025345 - m->m25 * B024345 ;
    double C02352345 = m->m20 * B235345 - m->m22 * B035345 + m->m23 * B025345 - m->m25 * B023345 ;
    double C02342345 = m->m20 * B234345 - m->m22 * B034345 + m->m23 * B024345 - m->m24 * B023345 ;
    double C01452345 = m->m20 * B145345 - m->m21 * B045345 + m->m24 * B015345 - m->m25 * B014345 ;
    double C01352345 = m->m20 * B135345 - m->m21 * B035345 + m->m23 * B015345 - m->m25 * B013345 ;
    double C01342345 = m->m20 * B134345 - m->m21 * B034345 + m->m23 * B014345 - m->m24 * B013345 ;
    double C01252345 = m->m20 * B125345 - m->m21 * B025345 + m->m22 * B015345 - m->m25 * B012345 ;
    double C01242345 = m->m20 * B124345 - m->m21 * B024345 + m->m22 * B014345 - m->m24 * B012345 ;
    double C01232345 = m->m20 * B123345 - m->m21 * B023345 + m->m22 * B013345 - m->m23 * B012345 ;
    double C23451345 = m->m12 * B345345 - m->m13 * B245345 + m->m14 * B235345 - m->m15 * B234345 ;
    double C13451345 = m->m11 * B345345 - m->m13 * B145345 + m->m14 * B135345 - m->m15 * B134345 ;
    double C12451345 = m->m11 * B245345 - m->m12 * B145345 + m->m14 * B125345 - m->m15 * B124345 ;
    double C12351345 = m->m11 * B235345 - m->m12 * B135345 + m->m13 * B125345 - m->m15 * B123345 ;
    double C12341345 = m->m11 * B234345 - m->m12 * B134345 + m->m13 * B124345 - m->m14 * B123345 ;
    double C23451245 = m->m12 * B345245 - m->m13 * B245245 + m->m14 * B235245 - m->m15 * B234245 ;
    double C13451245 = m->m11 * B345245 - m->m13 * B145245 + m->m14 * B135245 - m->m15 * B134245 ;
    double C12451245 = m->m11 * B245245 - m->m12 * B145245 + m->m14 * B125245 - m->m15 * B124245 ;
    double C12351245 = m->m11 * B235245 - m->m12 * B135245 + m->m13 * B125245 - m->m15 * B123245 ;
    double C12341245 = m->m11 * B234245 - m->m12 * B134245 + m->m13 * B124245 - m->m14 * B123245 ;
    double C23451235 = m->m12 * B345235 - m->m13 * B245235 + m->m14 * B235235 - m->m15 * B234235 ;
    double C13451235 = m->m11 * B345235 - m->m13 * B145235 + m->m14 * B135235 - m->m15 * B134235 ;
    double C12451235 = m->m11 * B245235 - m->m12 * B145235 + m->m14 * B125235 - m->m15 * B124235 ;
    double C12351235 = m->m11 * B235235 - m->m12 * B135235 + m->m13 * B125235 - m->m15 * B123235 ;
    double C12341235 = m->m11 * B234235 - m->m12 * B134235 + m->m13 * B124235 - m->m14 * B123235 ;
    double C23451234 = m->m12 * B345234 - m->m13 * B245234 + m->m14 * B235234 - m->m15 * B234234 ;
    double C13451234 = m->m11 * B345234 - m->m13 * B145234 + m->m14 * B135234 - m->m15 * B134234 ;
    double C12451234 = m->m11 * B245234 - m->m12 * B145234 + m->m14 * B125234 - m->m15 * B124234 ;
    double C12351234 = m->m11 * B235234 - m->m12 * B135234 + m->m13 * B125234 - m->m15 * B123234 ;
    double C12341234 = m->m11 * B234234 - m->m12 * B134234 + m->m13 * B124234 - m->m14 * B123234 ;
    double C03451345 = m->m10 * B345345 - m->m13 * B045345 + m->m14 * B035345 - m->m15 * B034345 ;
    double C02451345 = m->m10 * B245345 - m->m12 * B045345 + m->m14 * B025345 - m->m15 * B024345 ;
    double C02351345 = m->m10 * B235345 - m->m12 * B035345 + m->m13 * B025345 - m->m15 * B023345 ;
    double C02341345 = m->m10 * B234345 - m->m12 * B034345 + m->m13 * B024345 - m->m14 * B023345 ;
    double C03451245 = m->m10 * B345245 - m->m13 * B045245 + m->m14 * B035245 - m->m15 * B034245 ;
    double C02451245 = m->m10 * B245245 - m->m12 * B045245 + m->m14 * B025245 - m->m15 * B024245 ;
    double C02351245 = m->m10 * B235245 - m->m12 * B035245 + m->m13 * B025245 - m->m15 * B023245 ;
    double C02341245 = m->m10 * B234245 - m->m12 * B034245 + m->m13 * B024245 - m->m14 * B023245 ;
    double C03451235 = m->m10 * B345235 - m->m13 * B045235 + m->m14 * B035235 - m->m15 * B034235 ;
    double C02451235 = m->m10 * B245235 - m->m12 * B045235 + m->m14 * B025235 - m->m15 * B024235 ;
    double C02351235 = m->m10 * B235235 - m->m12 * B035235 + m->m13 * B025235 - m->m15 * B023235 ;
    double C02341235 = m->m10 * B234235 - m->m12 * B034235 + m->m13 * B024235 - m->m14 * B023235 ;
    double C03451234 = m->m10 * B345234 - m->m13 * B045234 + m->m14 * B035234 - m->m15 * B034234 ;
    double C02451234 = m->m10 * B245234 - m->m12 * B045234 + m->m14 * B025234 - m->m15 * B024234 ;
    double C02351234 = m->m10 * B235234 - m->m12 * B035234 + m->m13 * B025234 - m->m15 * B023234 ;
    double C02341234 = m->m10 * B234234 - m->m12 * B034234 + m->m13 * B024234 - m->m14 * B023234 ;
    double C01451345 = m->m10 * B145345 - m->m11 * B045345 + m->m14 * B015345 - m->m15 * B014345 ;
    double C01351345 = m->m10 * B135345 - m->m11 * B035345 + m->m13 * B015345 - m->m15 * B013345 ;
    double C01341345 = m->m10 * B134345 - m->m11 * B034345 + m->m13 * B014345 - m->m14 * B013345 ;
    double C01451245 = m->m10 * B145245 - m->m11 * B045245 + m->m14 * B015245 - m->m15 * B014245 ;
    double C01351245 = m->m10 * B135245 - m->m11 * B035245 + m->m13 * B015245 - m->m15 * B013245 ;
    double C01341245 = m->m10 * B134245 - m->m11 * B034245 + m->m13 * B014245 - m->m14 * B013245 ;
    double C01451235 = m->m10 * B145235 - m->m11 * B045235 + m->m14 * B015235 - m->m15 * B014235 ;
    double C01351235 = m->m10 * B135235 - m->m11 * B035235 + m->m13 * B015235 - m->m15 * B013235 ;
    double C01341235 = m->m10 * B134235 - m->m11 * B034235 + m->m13 * B014235 - m->m14 * B013235 ;
    double C01451234 = m->m10 * B145234 - m->m11 * B045234 + m->m14 * B015234 - m->m15 * B014234 ;
    double C01351234 = m->m10 * B135234 - m->m11 * B035234 + m->m13 * B015234 - m->m15 * B013234 ;
    double C01341234 = m->m10 * B134234 - m->m11 * B034234 + m->m13 * B014234 - m->m14 * B013234 ;
    double C01251345 = m->m10 * B125345 - m->m11 * B025345 + m->m12 * B015345 - m->m15 * B012345 ;
    double C01241345 = m->m10 * B124345 - m->m11 * B024345 + m->m12 * B014345 - m->m14 * B012345 ;
    double C01251245 = m->m10 * B125245 - m->m11 * B025245 + m->m12 * B015245 - m->m15 * B012245 ;
    double C01241245 = m->m10 * B124245 - m->m11 * B024245 + m->m12 * B014245 - m->m14 * B012245 ;
    double C01251235 = m->m10 * B125235 - m->m11 * B025235 + m->m12 * B015235 - m->m15 * B012235 ;
    double C01241235 = m->m10 * B124235 - m->m11 * B024235 + m->m12 * B014235 - m->m14 * B012235 ;
    double C01251234 = m->m10 * B125234 - m->m11 * B025234 + m->m12 * B015234 - m->m15 * B012234 ;
    double C01241234 = m->m10 * B124234 - m->m11 * B024234 + m->m12 * B014234 - m->m14 * B012234 ;
    double C01231345 = m->m10 * B123345 - m->m11 * B023345 + m->m12 * B013345 - m->m13 * B012345 ;
    double C01231245 = m->m10 * B123245 - m->m11 * B023245 + m->m12 * B013245 - m->m13 * B012245 ;
    double C01231235 = m->m10 * B123235 - m->m11 * B023235 + m->m12 * B013235 - m->m13 * B012235 ;
    double C01231234 = m->m10 * B123234 - m->m11 * B023234 + m->m12 * B013234 - m->m13 * B012234 ;

    double det = m->m00 * ( m->m11 * C23452345 - m->m12 * C13452345 + m->m13 * C12452345 - m->m14 * C12352345 + m->m15 * C12342345 )
        - m->m01 * ( m->m10 * C23452345 - m->m12 * C03452345 + m->m13 * C02452345 - m->m14 * C02352345 + m->m15 * C02342345 )
        + m->m02 * ( m->m10 * C13452345 - m->m11 * C03452345 + m->m13 * C01452345 - m->m14 * C01352345 + m->m15 * C01342345 )
        - m->m03 * ( m->m10 * C12452345 - m->m11 * C02452345 + m->m12 * C01452345 - m->m14 * C01252345 + m->m15 * C01242345 )
        + m->m04 * ( m->m10 * C12352345 - m->m11 * C02352345 + m->m12 * C01352345 - m->m13 * C01252345 + m->m15 * C01232345 )
        - m->m05 * ( m->m10 * C12342345 - m->m11 * C02342345 + m->m12 * C01342345 - m->m13 * C01242345 + m->m14 * C01232345 ) ;
    det = 1 / det;



    out->m00 = det *   ( m->m11 * C23452345 - m->m12 * C13452345 + m->m13 * C12452345 - m->m14 * C12352345 + m->m15 * C12342345 );
    out->m01 = det * - ( m->m01 * C23452345 - m->m02 * C13452345 + m->m03 * C12452345 - m->m04 * C12352345 + m->m05 * C12342345 );
    out->m02 = det *   ( m->m01 * C23451345 - m->m02 * C13451345 + m->m03 * C12451345 - m->m04 * C12351345 + m->m05 * C12341345 );
    out->m03 = det * - ( m->m01 * C23451245 - m->m02 * C13451245 + m->m03 * C12451245 - m->m04 * C12351245 + m->m05 * C12341245 );
    out->m04 = det *   ( m->m01 * C23451235 - m->m02 * C13451235 + m->m03 * C12451235 - m->m04 * C12351235 + m->m05 * C12341235 );
    out->m05 = det * - ( m->m01 * C23451234 - m->m02 * C13451234 + m->m03 * C12451234 - m->m04 * C12351234 + m->m05 * C12341234 );
    out->m10 = det * - ( m->m10 * C23452345 - m->m12 * C03452345 + m->m13 * C02452345 - m->m14 * C02352345 + m->m15 * C02342345 );
    out->m11 = det *   ( m->m00 * C23452345 - m->m02 * C03452345 + m->m03 * C02452345 - m->m04 * C02352345 + m->m05 * C02342345 );
    out->m12 = det * - ( m->m00 * C23451345 - m->m02 * C03451345 + m->m03 * C02451345 - m->m04 * C02351345 + m->m05 * C02341345 );
    out->m13 = det *   ( m->m00 * C23451245 - m->m02 * C03451245 + m->m03 * C02451245 - m->m04 * C02351245 + m->m05 * C02341245 );
    out->m14 = det * - ( m->m00 * C23451235 - m->m02 * C03451235 + m->m03 * C02451235 - m->m04 * C02351235 + m->m05 * C02341235 );
    out->m15 = det *   ( m->m00 * C23451234 - m->m02 * C03451234 + m->m03 * C02451234 - m->m04 * C02351234 + m->m05 * C02341234 );
    out->m20 = det *   ( m->m10 * C13452345 - m->m11 * C03452345 + m->m13 * C01452345 - m->m14 * C01352345 + m->m15 * C01342345 );
    out->m21 = det * - ( m->m00 * C13452345 - m->m01 * C03452345 + m->m03 * C01452345 - m->m04 * C01352345 + m->m05 * C01342345 );
    out->m22 = det *   ( m->m00 * C13451345 - m->m01 * C03451345 + m->m03 * C01451345 - m->m04 * C01351345 + m->m05 * C01341345 );
    out->m23 = det * - ( m->m00 * C13451245 - m->m01 * C03451245 + m->m03 * C01451245 - m->m04 * C01351245 + m->m05 * C01341245 );
    out->m24 = det *   ( m->m00 * C13451235 - m->m01 * C03451235 + m->m03 * C01451235 - m->m04 * C01351235 + m->m05 * C01341235 );
    out->m25 = det * - ( m->m00 * C13451234 - m->m01 * C03451234 + m->m03 * C01451234 - m->m04 * C01351234 + m->m05 * C01341234 );
    out->m30 = det * - ( m->m10 * C12452345 - m->m11 * C02452345 + m->m12 * C01452345 - m->m14 * C01252345 + m->m15 * C01242345 );
    out->m31 = det *   ( m->m00 * C12452345 - m->m01 * C02452345 + m->m02 * C01452345 - m->m04 * C01252345 + m->m05 * C01242345 );
    out->m32 = det * - ( m->m00 * C12451345 - m->m01 * C02451345 + m->m02 * C01451345 - m->m04 * C01251345 + m->m05 * C01241345 );
    out->m33 = det *   ( m->m00 * C12451245 - m->m01 * C02451245 + m->m02 * C01451245 - m->m04 * C01251245 + m->m05 * C01241245 );
    out->m34 = det * - ( m->m00 * C12451235 - m->m01 * C02451235 + m->m02 * C01451235 - m->m04 * C01251235 + m->m05 * C01241235 );
    out->m35 = det *   ( m->m00 * C12451234 - m->m01 * C02451234 + m->m02 * C01451234 - m->m04 * C01251234 + m->m05 * C01241234 );
    out->m40 = det *   ( m->m10 * C12352345 - m->m11 * C02352345 + m->m12 * C01352345 - m->m13 * C01252345 + m->m15 * C01232345 );
    out->m41 = det * - ( m->m00 * C12352345 - m->m01 * C02352345 + m->m02 * C01352345 - m->m03 * C01252345 + m->m05 * C01232345 );
    out->m42 = det *   ( m->m00 * C12351345 - m->m01 * C02351345 + m->m02 * C01351345 - m->m03 * C01251345 + m->m05 * C01231345 );
    out->m43 = det * - ( m->m00 * C12351245 - m->m01 * C02351245 + m->m02 * C01351245 - m->m03 * C01251245 + m->m05 * C01231245 );
    out->m44 = det *   ( m->m00 * C12351235 - m->m01 * C02351235 + m->m02 * C01351235 - m->m03 * C01251235 + m->m05 * C01231235 );
    out->m45 = det * - ( m->m00 * C12351234 - m->m01 * C02351234 + m->m02 * C01351234 - m->m03 * C01251234 + m->m05 * C01231234 );
    out->m50 = det * - ( m->m10 * C12342345 - m->m11 * C02342345 + m->m12 * C01342345 - m->m13 * C01242345 + m->m14 * C01232345 );
    out->m51 = det *   ( m->m00 * C12342345 - m->m01 * C02342345 + m->m02 * C01342345 - m->m03 * C01242345 + m->m04 * C01232345 );
    out->m52 = det * - ( m->m00 * C12341345 - m->m01 * C02341345 + m->m02 * C01341345 - m->m03 * C01241345 + m->m04 * C01231345 );
    out->m53 = det *   ( m->m00 * C12341245 - m->m01 * C02341245 + m->m02 * C01341245 - m->m03 * C01241245 + m->m04 * C01231245 );
    out->m54 = det * - ( m->m00 * C12341235 - m->m01 * C02341235 + m->m02 * C01341235 - m->m03 * C01241235 + m->m04 * C01231235 );
    out->m55 = det *   ( m->m00 * C12341234 - m->m01 * C02341234 + m->m02 * C01341234 - m->m03 * C01241234 + m->m04 * C01231234 );

}



void eMatrix::mat6x6GJInverse(float matrix[10][10], float inverse[10][10]) {
    // Initialize the inverse matrix as the identity matrix
    for (int i = 0; i < SIZE; i++) {
        for (int j = 0; j < SIZE; j++) {
            inverse[i][j] = (i == j) ? 1.0 : 0.0;
        }
    }

    // Perform Gauss-Jordan elimination
    for (int i = 0; i < SIZE; i++) {
        // Find the pivot element
    	float pivot = matrix[i][i];
        if (fabs(pivot) < EPSILON) {
        	assert(false);
        }


        // Normalize the pivot row
        for (int j = 0; j < SIZE; j++) {
            matrix[i][j] /= pivot;
            inverse[i][j] /= pivot;
        }

        // Eliminate other rows
        for (int k = 0; k < SIZE; k++) {
            if (k != i) {
            	float factor = matrix[k][i];
                for (int j = 0; j < SIZE; j++) {
                    matrix[k][j] -= factor * matrix[i][j];
                    inverse[k][j] -= factor * inverse[i][j];
                }
            }
        }
    }
}

