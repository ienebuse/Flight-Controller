/*
 * eVector.h
 *
 *  Created on: Jul 24, 2024
 *      Author: ienebuse
 */

#ifndef EKF_EKFMATH_EVECTOR_H_
#define EKF_EKFMATH_EVECTOR_H_

#include <assert.h>
#include <stdint.h>
#include <typedefs.h>

class eVector
{
public:
    float arr[10];
    uint8_t size = 10;

    eVector() {
    	for(uint8_t s = 0; s < size; s++) {
			arr[s] = 0;
		}
    }
//    virtual ~eVector();

    eVector(uint8_t size) : size(size){
    	for(uint8_t s = 0; s < size; s++) {
			arr[s] = 0;
		}
    }

    eVector(eVector v1, eVector v2) {
    	assert((v1.size + v2.size) < size);
    	uint8_t s = 0;
    	while(s < v1.size) {
    		arr[s] = v1[s];
    		s++;
    	}

    	while(s < v1.size + v1.size) {
    		arr[s] = v2[s-v1.size];
    		s++;
    	}

    	size = v1.size + v2.size ;

    }

    eVector(Vector_t<float> v) {
    	arr[0] = v.x;
    	arr[1] = v.y;
    	arr[2] = v.z;
    	size = 3;
    }

    eVector(Quaternion_t q) {
    	arr[0] = q.q0;
    	arr[1] = q.q1;
    	arr[2] = q.q2;
    	arr[2] = q.q3;
    	size = 4;
    }

    inline eVector operator +(eVector v) {
        assert(size == v.size);
        eVector vec(size);
        for(uint8_t s = 0; s < size; s++) {
            vec.arr[s] = arr[s] + v.arr[s];
        }
        return vec;
    }

    inline eVector operator -(eVector v) {
        assert(size == v.size);
        eVector vec(size);
        for(uint8_t s = 0; s < size; s++) {
            vec.arr[s] = arr[s] - v.arr[s];
        }
        return vec;
    }

    inline eVector& operator +=(eVector v) {
		assert(size == v.size);
		for(uint8_t s = 0; s < size; s++) {
			arr[s] += v.arr[s];
		}
		return *(eVector*)this;
	}

    inline float& operator [](uint8_t index) {
    	assert(index >= 0 && index < size);
    	return arr[index];
    }
};

#endif /* EKF_EKFMATH_EVECTOR_H_ */
