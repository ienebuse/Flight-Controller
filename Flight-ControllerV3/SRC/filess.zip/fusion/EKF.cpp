/*
 * EKF.cpp
 *
 *  Created on: Jul 24, 2024
 *      Author: ienebuse
 */

#include <EKF.h>

static float fastInvereSqrt(float number) {
    // 1. Type punning using a union to interpret float bits as integer
    union {
        float f;
        uint32_t i;
    } conv;

    // 2. Initial approximation
    float x2 = number * 0.5f;
    const float threehalfs = 1.5f;

    conv.f = number;
    conv.i = 0x5f3759df - (conv.i >> 1); // Bit-level hack

    // 3. Newton's method iteration
    conv.f = conv.f * (threehalfs - (x2 * conv.f * conv.f));

    return conv.f;
}

#if (USE_ACC_EST == 1)
	#if (USE_GYRO_BIAS == 1)

	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,1),Q(7,7,0.001), R(6,6,0.1), I(7,7,1)
	EKF::EKF(Attitude* att): Filter(att), x(10), P(10,10,1000000),Q(10,10,0.001), R(6,6,1), I(10,10,1)
	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,100000),Q(7,7,0.00001), R(6,6,1), I(7,7,1)
	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,10),Q(7,7,2), R(6,6,4), I(7,7,1)
	{
		// TODO Auto-generated constructor stub

	}
	#else
	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,1),Q(7,7,0.001), R(6,6,0.1), I(7,7,1)
	EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,1),Q(7,7,0.00001), R(6,6,0.5), I(7,7,1)
	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,100000),Q(7,7,0.00001), R(6,6,1), I(7,7,1)
	//EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,10),Q(7,7,2), R(6,6,4), I(7,7,1)
	{
		// TODO Auto-generated constructor stub
		R = MatR(2, 5);
	}
	#endif

#else

#if (USE_GYRO_BIAS == 1)

EKF::EKF(Attitude* att): Filter(att), x(7), P(7,7,1),Q(7,7,0.001), R(6,6,0.1), I(7,7,1)
{
    // TODO Auto-generated constructor stub
	R = MatR(2, 8);

}
#else
EKF::EKF(Attitude* att): Filter(att), x(4), P(4,4,1),Q(4,4,0.00001), R(6,6,0.5), I(4,4,1)
{
    // TODO Auto-generated constructor stub
//	R = MatR(0.5, 10);
	R = MatR(0.1, 0.5);

}
#endif

#endif

EKF::~EKF()
{
    // TODO Auto-generated destructor stub
}

void EKF::normalizeState() {

#if (USE_ACC_EST == 1)

	float sumSq = x[0]*x[0] + x[1]*x[1] + x[2]*x[2] + x[3]*x[3];
//	float invSumSq = fastInvereSqrt(sumSq);
	float invSumSq = 1/sqrt(sumSq);
	x[0] *= invSumSq;
	x[1] *= invSumSq;
	x[2] *= invSumSq;
	x[3] *= invSumSq;

#elif(USE_VEL_EST == 1)
	float sumSq = x[3]*x[3] + x[4]*x[4] + x[5]*x[5] + x[6]*x[6];
//	float invSumSq = fastInvereSqrt(sumSq);
	float invSumSq = 1/sqrt(sumSq);
	x[3] *= invSumSq;
	x[4] *= invSumSq;
	x[5] *= invSumSq;
	x[6] *= invSumSq;
#else
	float sumSq = x[0]*x[0] + x[1]*x[1] + x[2]*x[2] + x[3]*x[3];
//	float invSumSq = fastInvereSqrt(sumSq);
	float invSumSq = 1/sqrt(sumSq);
	x[0] *= invSumSq;
	x[1] *= invSumSq;
	x[2] *= invSumSq;
	x[3] *= invSumSq;
#endif
}

void EKF::prediction (Vector_t<float> gyro, float dT) {
    // State transition
    //qk = qk-1 + 0.5dT[w]x qk-1
//	dT = 0.0013;

#if (USE_ACC_EST == 1)
	#if (USE_GYRO_BIAS == 1)

		x[0] = q.q0 + 0.5*dT*(-q.q1*(gyro.x - b.x) - q.q2*(gyro.y - b.y) - q.q3*(gyro.z - b.z));
		x[1] = q.q1 + 0.5*dT*(q.q0*(gyro.x - b.x) + q.q2*(gyro.z - b.y) - q.q3*(gyro.y - b.z));
		x[2] = q.q2 + 0.5*dT*(q.q0*(gyro.y - b.x) - q.q1*(gyro.z - b.y) + q.q3*(gyro.x - b.z));
		x[3] = q.q3 + 0.5*dT*(q.q0*(gyro.z - b.x) + q.q1*(gyro.y - b.y) - q.q2*(gyro.x - b.z));

		q.q0 = x[0];
		q.q1 = x[1];
		q.q2 = x[2];
		q.q3 = x[3];
		ai.x = x[4];
		ai.y = x[5];
		ai.z = x[6];
		b.x = x[7];
		b.y = x[8];
		b.z = x[9];

		MatF F(q, gyro, b, dT);

	#else
		x[0] = q.q0 + 0.5*dT*(-q.q1*(gyro.x) - q.q2*(gyro.y) - q.q3*(gyro.z));
		x[1] = q.q1 + 0.5*dT*(q.q0*(gyro.x) + q.q2*(gyro.z) - q.q3*(gyro.y));
		x[2] = q.q2 + 0.5*dT*(q.q0*(gyro.y) - q.q1*(gyro.z) + q.q3*(gyro.x));
		x[3] = q.q3 + 0.5*dT*(q.q0*(gyro.z) + q.q1*(gyro.y) - q.q2*(gyro.x));

		q.q0 = x[0];
		q.q1 = x[1];
		q.q2 = x[2];
		q.q3 = x[3];

		ai.x = x[4];
		ai.y = x[5];
		ai.z = x[6];

		MatF F(gyro, dT);
	#endif

#elif (USE_VEL_EST == 1)

	VecRa Ra(q, a);
	ai = {Ra[0], Ra[1], Ra[2] - g.z};

	x[0] = x[0] + ai.x * dT;
	x[1] = x[1] + ai.y * dT;
	x[2] = x[2] + ai.z * dT;

    x[3] = x[3] + 0.5*dT*(-x[4]*(gyro.x) - x[5]*(gyro.y) - x[6]*(gyro.z));
    x[4] = x[4] + 0.5*dT*(x[3]*(gyro.x) + x[5]*(gyro.z) - x[6]*(gyro.y));
    x[5] = x[5] + 0.5*dT*(x[3]*(gyro.y) - x[4]*(gyro.z) + x[6]*(gyro.x));
    x[6] = x[6] + 0.5*dT*(x[3]*(gyro.z) + x[4]*(gyro.y) - x[5]*(gyro.x));

    q.q0 = x[3];
	q.q1 = x[4];
	q.q2 = x[5];
	q.q3 = x[6];

	MatF F(q, ai, gyro, dT);

#elif (USE_GYRO_BIAS == 1)
    x[0] = q.q0 + 0.5*dT*(-q.q1*(gyro.x - x[4]) - q.q2*(gyro.y - x[5]) - q.q3*(gyro.z - x[6]));
    x[1] = q.q1 + 0.5*dT*(q.q0*(gyro.x - x[4]) + q.q2*(gyro.z - x[6]) - q.q3*(gyro.y - x[5]));
    x[2] = q.q2 + 0.5*dT*(q.q0*(gyro.y - x[5]) - q.q1*(gyro.z - x[6]) + q.q3*(gyro.x - x[4]));
    x[3] = q.q3 + 0.5*dT*(q.q0*(gyro.z - x[6]) + q.q1*(gyro.y - x[5]) - q.q2*(gyro.x - x[4]));



    q.q0 = x[0];
	q.q1 = x[1];
	q.q2 = x[2];
	q.q3 = x[3];
	b.x = x[4];
	b.y = x[5];
	b.z = x[6];

	MatF F(q, gyro, b, dT);

#else
//    x[0] = x[0] + 0.5*dT*(-x[1]*(gyro.x) - x[2]*(gyro.y) - x[3]*(gyro.z));
//    x[1] = x[1] + 0.5*dT*(x[0]*(gyro.x) + x[2]*(gyro.z) - x[3]*(gyro.y));
//    x[2] = x[2] + 0.5*dT*(x[0]*(gyro.y) - x[1]*(gyro.z) + x[3]*(gyro.x));
//    x[3] = x[3] + 0.5*dT*(x[0]*(gyro.z) + x[1]*(gyro.y) - x[2]*(gyro.x));

    x[0] = q.q0 + 0.5*dT*(-q.q1*(gyro.x) - q.q2*(gyro.y) - q.q3*(gyro.z));
	x[1] = q.q1 + 0.5*dT*(q.q0*(gyro.x) + q.q2*(gyro.z) - q.q3*(gyro.y));
	x[2] = q.q2 + 0.5*dT*(q.q0*(gyro.y) - q.q1*(gyro.z) + q.q3*(gyro.x));
	x[3] = q.q3 + 0.5*dT*(q.q0*(gyro.z) + q.q1*(gyro.y) - q.q2*(gyro.x));

    q.q0 = x[0];
	q.q1 = x[1];
	q.q2 = x[2];
	q.q3 = x[3];

	MatF F(gyro, dT);

#endif

    P = F * P * F.T() + Q;
}

bool EKF::checkMagData(Vector_t<float> mag) {
	VecRTa Mag(q,M);
	float cosM = mag.x * Mag[0] + mag.y * Mag[1] + mag.z * Mag[2];
//	return cosM  > 0.95;
	return true;
}

bool EKF::checkAccData(Vector_t<float> acc) {
//	return true;
	VecRTa Acc(q,g);
	float cosM = acc.x * Acc[0] + acc.y * Acc[1] + acc.z * Acc[2];
//	return cosM  > 0.97;
	return true;
}

void EKF::update(Vector_t<float> acc, Vector_t<float> mag, bool magAvailable) {

//	magAvailable = false;
	if(magAvailable && checkMagData(mag)) {

#if (USE_ACC_EST == 1)

//		VecRa Ze(q,mag);
//		Ze[0] = sqrt(Ze[0]*Ze[0] + Ze[1]*Ze[1]);
//		Ze[1] = 0;
//		Vector_t<float> vZe = {Ze[0],0,Ze[2]};
//		VecRTa Zs(q,vZe);
//		Vector_t<float>magS = {Zs[0],Zs[1],Zs[2]};

		VecZ Z(acc, mag);
		Vector_t<float> ag = {ai.x, ai.y, ai.z - g.z};

		float mSqInv = 1/sqrt(ag.x*ag.x + ag.y*ag.y + ag.z*ag.z);
		ag.x *= mSqInv;
		ag.y *= mSqInv;
		ag.z *= mSqInv;


		VecHx Hx(q, ag, M);
		MatH H(q, ag, M);
//		VecHx Hx(q, g, M);
//		MatH H(q, g, M);

		eVector y = Z - Hx;

#elif (USE_VEL_EST == 1)
		VecZ Z(acc);
		VecRTa accB(q, ai);
		Vector_t<float> ag = {Z[0] - accB[0],
							  Z[1] - accB[1],
							  Z[2] - accB[2]
		};

		float mSqInv = 1/sqrt(ag.x*ag.x + ag.y*ag.y + ag.z*ag.z);
		ag.x *= mSqInv;
		ag.y *= mSqInv;
		ag.z *= mSqInv;

		Vector_t<float> _g = {0,0,-1};

		VecZ Zg(ag, mag);
		VecHx Hx(q, _g, M);
		MatH H(q, _g, M);

		eVector y = Zg - Hx;
#else
		VecZ Z(acc, mag);
		VecHx Hx(q, g, M);
		MatH H(q, g, M);

		eVector y = Z - Hx;
#endif
		eMatrix S = (H * P * H.T()) + R;
		eMatrix K = P * H.T() * S.inv(6);

		x = x + K * y;
		if(std::isnan(x[0]) || std::isnan(x[1]) || std::isnan(x[2]) || std::isnan(x[3])) {
			reset();
			return;
		}
		x_ = x;
		P = (I - K * H) * P;
	}
	else if(checkAccData(acc)) {
		VecZ Z(acc);

#if (USE_ACC_EST == 1)
		Vector_t<float> ag = {ai.x, ai.y, ai.z + g.z};

		float mSqInv = 1/sqrt(ag.x*ag.x + ag.y*ag.y + ag.z*ag.z);
		ag.x *= mSqInv;
		ag.y *= mSqInv;
		ag.z *= mSqInv;

		VecHx Hx(q, ag);
		MatH H(q, ag);

		eVector y = Z - Hx;
#elif (USE_VEL_EST == 1)
		VecRTa accB(q, ai);
		Vector_t<float> ag = {Z[0] - accB[0],
							  Z[1] - accB[1],
							  Z[2] - accB[2]
		};

		float mSqInv = 1/sqrt(ag.x*ag.x + ag.y*ag.y + ag.z*ag.z);
		ag.x *= mSqInv;
		ag.y *= mSqInv;
		ag.z *= mSqInv;

		Vector_t<float> _g = {0,0,-1};

		VecZ Zg(ag);
		VecHx Hx(q, _g);
		MatH H(q, _g);

		eVector y = Zg - Hx;
#else
		VecHx Hx(q, g);
		MatH H(q, g);

		eVector y = Z - Hx;
#endif

		eMatrix S = H * P * H.T() + R(3,3);
		eMatrix K = P * H.T() * S.inv(3);
		x = x + K * y;
		if(std::isnan(x[0]) || std::isnan(x[1]) || std::isnan(x[2]) || std::isnan(x[3])) {
			reset();
			return;
		}
		x_ = x;
		P = (I - K * H) * P;
	}

	normalizeState();

#if (USE_ACC_EST == 1)
	att->quat.q0 = x[0];
	att->quat.q1 = x[1];
	att->quat.q2 = x[2];
	att->quat.q3 = x[3];

	q.q0 = x[0];
	q.q1 = x[1];
	q.q2 = x[2];
	q.q3 = x[3];
	ai.x = x[4];
	ai.y = x[5];
	ai.z = x[6];
	#if (USE_GYRO_BIAS == 1)
		b.x = x[7];
		b.y = x[8];
		b.z = x[9];
	#endif

#elif(USE_VEL_EST)
	att->vel.x = x[0];
	att->vel.y = x[1];
	att->vel.z = x[2];
	att->quat.q0 = x[3];
	att->quat.q1 = x[4];
	att->quat.q2 = x[5];
	att->quat.q3 = x[6];

	v.x = x[0];
	v.y = x[1];
	v.z = x[2];
	q.q0 = x[3];
	q.q1 = x[4];
	q.q2 = x[5];
	q.q3 = x[6];

	a.x = acc.x;
	a.y = acc.y;
	a.z = acc.z;
#elif (USE_GYRO_BIAS == 1)
	att->quat.q0 = x[0];
	att->quat.q1 = x[1];
	att->quat.q2 = x[2];
	att->quat.q3 = x[3];

	q.q0 = x[0];
	q.q1 = x[1];
	q.q2 = x[2];
	q.q3 = x[3];
	b.x = x[4];
	b.y = x[5];
	b.z = x[6];
#else
	att->quat.q0 = x[0];
	att->quat.q1 = x[1];
	att->quat.q2 = x[2];
	att->quat.q3 = x[3];
	q.q0 = x[0];
	q.q1 = x[1];
	q.q2 = x[2];
	q.q3 = x[3];
#endif
}

void EKF::update(float ax, float ay, float az, float gx, float gy, float gz, float mx, float my, float mz, float dT, bool magAvailable) {

	float mSqInv = 0;
//	m_firstMeasurement = true;
//	mz = -mz;


//	mSqInv = fastInvereSqrt(ax*ax + ay*ay + az*az);




	if(m_firstMeasurement) {

		a.x = ax*9.81;
		a.y = ay*9.81;
		a.z = az*9.81;

		mSqInv = 1/sqrt(ax*ax + ay*ay + az*az);
		ax *= mSqInv;
		ay *= mSqInv;
		az *= mSqInv;

		mSqInv = 1/sqrt(mx*mx + my*my + mz*mz);
		mx *= mSqInv;
		my *= mSqInv;
		mz *= mSqInv;
		getInitialOrientation(ax, ay, az, mx, my, mz);
//		getInitialOrientation(ax, ay, az, 1, 0, 0);
		q.q0 = att->quat.q0;
		q.q1 = att->quat.q1;
		q.q2 = att->quat.q2;
		q.q3 = att->quat.q3;

		Vector_t<float> m = {mx,my,mz};
//		Vector_t<float> m = {1,0,0};
		VecRa Mi(q,m);
		Vector_t<float> mt = {Mi[0],Mi[1],Mi[2]};
		VecRTa Mt(q,mt);
//		mSqInv = 1/sqrt(Mi[0]*Mi[0] + Mi[1]*Mi[1] + Mi[2]*Mi[2]);
		M.x = Mi[0];
		M.y = Mi[1];
		M.z = Mi[2];

//		mSqInv = 1/sqrt(Mi[0]*Mi[0] + Mi[1]*Mi[1] + Mi[2]*Mi[2]);
//		M.x = Mi[0]*mSqInv;
//		M.y = Mi[1]*mSqInv;
//		M.z = Mi[2]*mSqInv;


//		M.x = 1;
//		M.y = 0;
//		M.z = 0;
#if (USE_ACC_EST == 1)

		x[0] = q.q0;
		x[1] = q.q1;
		x[2] = q.q2;
		x[3] = q.q3;
		x[4] = 0.0;
		x[5] = 0.0;
		x[6] = 0.0;

#elif (USE_VEL_EST == 1)
		x[0] = 0;
		x[1] = 0;
		x[2] = 0;
		x[3] = q.q0;
		x[4] = q.q1;
		x[5] = q.q2;
		x[6] = q.q3;

		g.z *= -9.81;
#elif (USE_GYRO_BIAS == 1)
		x[0] = q.q0;
		x[1] = q.q1;
		x[2] = q.q2;
		x[3] = q.q3;
		x[4] = 0.0*DEG2RAD;
		x[5] = 0.0*DEG2RAD;
		x[6] = 0.0*DEG2RAD;
#else
		x[0] = q.q0;
		x[1] = q.q1;
		x[2] = q.q2;
		x[3] = q.q3;
#endif
		m_firstMeasurement = false;
		return;
	}



//	mSqInv = fastInvereSqrt(mx*mx + my*my + mz*mz);
	mSqInv = 1/sqrt(mx*mx + my*my + mz*mz);
	mx *= mSqInv;
	my *= mSqInv;
	mz *= mSqInv;


#if(USE_ACC_EST == 1)
	mSqInv = 1/sqrt(ax*ax + ay*ay + az*az);
	ax *= mSqInv;
	ay *= mSqInv;
	az *= mSqInv;

#elif(USE_VEL_EST == 0)
	mSqInv = 1/sqrt(ax*ax + ay*ay + az*az);
	ax *= mSqInv;
	ay *= mSqInv;
	az *= mSqInv;
#else
	ax *= 9.81;
	ay *= 9.81;
	az *= 9.81;
#endif

	Vector_t<float> gyro = {gx,gy,gz};
	Vector_t<float> accel = {ax,ay,az};
	Vector_t<float> mag = {mx,my,mz};

//	dT = 0.0013;
	prediction(gyro, dT);
	update(accel, mag, magAvailable);
}

