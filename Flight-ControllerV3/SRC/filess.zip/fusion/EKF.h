/*
 * EKF.h
 *
 *  Created on: Jul 24, 2024
 *      Author: ienebuse
 */

#ifndef EKF_EKF_H_
#define EKF_EKF_H_

#include <EKFMath/eMatrix.h>
#include <EKFMath/eVector.h>
#include <Filter.h>

class EKF : public Filter
{
public:
    EKF(Attitude* att);
    virtual ~EKF();

    void prediction (Vector_t<float> gyro, float dT);
    void update(Vector_t<float> acc, Vector_t<float> mag, bool magAvailable = true);

    void update(float ax, float ay, float az, float gx, float gy, float gz, float mx, float my, float mz, float dT, bool magAvailable = true);

    void reset() {
//    	m_firstMeasurement = true;
    	P.resetDiag(0.05);
    	x = x_;
    }

private:
    Quaternion_t q;
    Vector_t<float> a, ai;
    Vector_t<float> v;
    Vector_t <float> b = {0,0,0};
    Vector_t <float> M = {1,0,0};
	Vector_t <float> g = {0,0,1};
    eVector x, x_;
    eMatrix P, Q, R, I;
//    const double dT = 0.001;

    bool m_firstMeasurement = true;

    void normalizeState();

    bool checkMagData(Vector_t<float> mag);

    bool checkAccData(Vector_t<float> acc);
};

class VecZ : public eVector
{
public:

    VecZ(Vector_t<float> a, Vector_t<float> m) : eVector(6) {

    	arr[0] = a.x;
    	arr[1] = a.y;
    	arr[2] = a.z;
    	arr[3] = m.x;
    	arr[4] = m.y;
    	arr[5] = m.z;
    };

    VecZ(Vector_t<float> a) : eVector(3) {

    	arr[0] = a.x;
    	arr[1] = a.y;
    	arr[2] = a.z;
    };


};

class MatR : public eMatrix
{
public:

	MatR(float eAcc, float eMag) : eMatrix(6,6) {
        arr[0][0] = eAcc;
        arr[0][1] = 0;
        arr[0][2] = 0;
        arr[0][3] = 0;
        arr[0][4] = 0;
        arr[0][5] = 0;

        arr[1][0] = 0;
        arr[1][1] = eAcc;
        arr[1][2] = 0;
        arr[1][3] = 0;
        arr[1][4] = 0;
        arr[1][5] = 0;

        arr[2][0] = 0;
        arr[2][1] = 0;
        arr[2][2] = eAcc;
        arr[2][3] = 0;
        arr[2][4] = 0;
        arr[2][5] = 0;



        arr[3][0] = 0;
        arr[3][1] = 0;
        arr[3][2] = 0;
        arr[3][3] = eMag;
        arr[3][4] = 0;
        arr[3][5] = 0;

        arr[4][0] = 0;
        arr[4][1] = 0;
        arr[4][2] = 0;
        arr[4][3] = 0;
        arr[4][4] = eMag;
        arr[4][5] = 0;

        arr[5][0] = 0;
        arr[5][1] = 0;
        arr[5][2] = 0;
        arr[5][3] = 0;
        arr[5][4] = 0;
        arr[5][5] = eMag;
	}
};



class VecRa : public eVector
{
public:

    VecRa(Quaternion_t q, Vector_t<float> a) : eVector(3) {

    	float q02 = q.q0*q.q0;
    	float q12 = q.q1*q.q1;
    	float q22 = q.q2*q.q2;
    	float q32 = q.q3*q.q3;

    	float _2q1q3 = 2*q.q1*q.q3;
    	float _2q0q2 = 2*q.q0*q.q2;
    	float _2q2q3 = 2*q.q2*q.q3;
    	float _2q0q1 = 2*q.q0*q.q1;
    	float _2q1q2 = 2*q.q1*q.q2;
    	float _2q0q3 = 2*q.q0*q.q3;

    	arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 - _2q0q3) + a.z*(_2q1q3 + _2q0q2);
    	arr[1] = a.x*(_2q1q2 + _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 - _2q0q1);
    	arr[2] = a.x*(_2q1q3 - _2q0q2) + a.y*(_2q2q3 + _2q0q1) + a.z*(q02 - q12 - q22 + q32);
    };
};

class VecRTa : public eVector
{
public:

    VecRTa(Quaternion_t q, Vector_t<float> a) : eVector(3) {

    	float q02 = q.q0*q.q0;
    	float q12 = q.q1*q.q1;
    	float q22 = q.q2*q.q2;
    	float q32 = q.q3*q.q3;

    	float _2q1q3 = 2*q.q1*q.q3;
    	float _2q0q2 = 2*q.q0*q.q2;
    	float _2q2q3 = 2*q.q2*q.q3;
    	float _2q0q1 = 2*q.q0*q.q1;
    	float _2q1q2 = 2*q.q1*q.q2;
    	float _2q0q3 = 2*q.q0*q.q3;

    	arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 + _2q0q3) + a.z*(_2q1q3 - _2q0q2);
    	arr[1] = a.x*(_2q1q2 - _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 + _2q0q1);
    	arr[2] = a.x*(_2q1q3 + _2q0q2) + a.y*(_2q2q3 - _2q0q1) + a.z*(q02 - q12 - q22 + q32);
    };
};


#if (USE_VEL_EST == 1) || USE_ACC_EST == 1

	#if (USE_GYRO_BIAS == 1)

		class VecHx : public eVector
		{
		public:

			VecHx(Quaternion_t q, Vector_t<float> a, Vector_t<float> m) : eVector(6) {

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;

				arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 + _2q0q3) + a.z*(_2q1q3 - _2q0q2);
				arr[1] = a.x*(_2q1q2 - _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 + _2q0q1);
				arr[2] = a.x*(_2q1q3 + _2q0q2) + a.y*(_2q2q3 - _2q0q1) + a.z*(q02 - q12 - q22 + q32);
				arr[3] = m.x*(q02 + q12 - q22 - q32) + m.y*(_2q1q2 + _2q0q3) + m.z*(_2q1q3 - _2q0q2);
				arr[4] = m.x*(_2q1q2 - _2q0q3) + m.y*(q02 - q12 + q22 - q32) + m.z*(_2q2q3 + _2q0q1);
				arr[5] = m.x*(_2q1q3 + _2q0q2) + m.y*(_2q2q3 - _2q0q1) + m.z*(q02 - q12 - q22 + q32);
			};

			VecHx(Quaternion_t q, Vector_t<float> a) : eVector(3) {

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;

				arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 + _2q0q3) + a.z*(_2q1q3 - _2q0q2);
				arr[1] = a.x*(_2q1q2 - _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 + _2q0q1);
				arr[2] = a.x*(_2q1q3 + _2q0q2) + a.y*(_2q2q3 - _2q0q1) + a.z*(q02 - q12 - q22 + q32);
			};


		};

	#else
		class VecHx : public eVector
		{
		public:

			VecHx(Quaternion_t q, Vector_t<float> a, Vector_t<float> m) : eVector(6) {

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;

				arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 + _2q0q3) + a.z*(_2q1q3 - _2q0q2);
				arr[1] = a.x*(_2q1q2 - _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 + _2q0q1);
				arr[2] = a.x*(_2q1q3 + _2q0q2) + a.y*(_2q2q3 - _2q0q1) + a.z*(q02 - q12 - q22 + q32);
				arr[3] = m.x*(q02 + q12 - q22 - q32) + m.y*(_2q1q2 + _2q0q3) + m.z*(_2q1q3 - _2q0q2);
				arr[4] = m.x*(_2q1q2 - _2q0q3) + m.y*(q02 - q12 + q22 - q32) + m.z*(_2q2q3 + _2q0q1);
				arr[5] = m.x*(_2q1q3 + _2q0q2) + m.y*(_2q2q3 - _2q0q1) + m.z*(q02 - q12 - q22 + q32);
			};

			VecHx(Quaternion_t q, Vector_t<float> a) : eVector(3) {

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;

				arr[0] = a.x*(q02 + q12 - q22 - q32) + a.y*(_2q1q2 + _2q0q3) + a.z*(_2q1q3 - _2q0q2);
				arr[1] = a.x*(_2q1q2 - _2q0q3) + a.y*(q02 - q12 + q22 - q32) + a.z*(_2q2q3 + _2q0q1);
				arr[2] = a.x*(_2q1q3 + _2q0q2) + a.y*(_2q2q3 - _2q0q1) + a.z*(q02 - q12 - q22 + q32);
			};


		};
	#endif

#else

class VecHx : public eVector
{
public:

    VecHx(Quaternion_t q, Vector_t<float> g, Vector_t<float> m) : eVector(6) {

    	float q02 = q.q0*q.q0;
    	float q12 = q.q1*q.q1;
    	float q22 = q.q2*q.q2;
    	float q32 = q.q3*q.q3;

    	float _2q1q3 = 2*q.q1*q.q3;
    	float _2q0q2 = 2*q.q0*q.q2;
    	float _2q2q3 = 2*q.q2*q.q3;
    	float _2q0q1 = 2*q.q0*q.q1;
    	float _2q1q2 = 2*q.q1*q.q2;
    	float _2q0q3 = 2*q.q0*q.q3;

    	arr[0] = g.z*(_2q1q3 - _2q0q2);
    	arr[1] = g.z*(_2q2q3 + _2q0q1);
    	arr[2] = g.z*(q02 - q12 - q22 + q32);
    	arr[3] = m.x*(q02 + q12 - q22 - q32) + m.y*(_2q1q2 + _2q0q3) + m.z*(_2q1q3 - _2q0q2);
    	arr[4] = m.x*(_2q1q2 - _2q0q3) + m.y*(q02 - q12 + q22 - q32) + m.z*(_2q2q3 + _2q0q1);
    	arr[5] = m.x*(_2q1q3 + _2q0q2) + m.y*(_2q2q3 - _2q0q1) + m.z*(q02 - q12 - q22 + q32);
    };

    VecHx(Quaternion_t q, Vector_t<float> g) : eVector(3) {

    	float q02 = q.q0*q.q0;
    	float q12 = q.q1*q.q1;
    	float q22 = q.q2*q.q2;
    	float q32 = q.q3*q.q3;

    	float _2q1q3 = 2*q.q1*q.q3;
    	float _2q0q2 = 2*q.q0*q.q2;
    	float _2q2q3 = 2*q.q2*q.q3;
    	float _2q0q1 = 2*q.q0*q.q1;

    	arr[0] = g.z*(_2q1q3 - _2q0q2);
    	arr[1] = g.z*(_2q2q3 + _2q0q1);
    	arr[2] = g.z*(q02 - q12 - q22 + q32);
    };


};

#endif

#if(USE_ACC_EST == 1)

	#if (USE_GYRO_BIAS == 1)
		class MatH : public eMatrix
		{
		public:

			MatH(Quaternion_t q, Vector_t<float> a, Vector_t<float> m) : eMatrix(6,10) {

				const float _2q0ax = 2*q.q0*a.x;
				const float _2q1ax = 2*q.q1*a.x;
				const float _2q2ax = 2*q.q2*a.x;
				const float _2q3ax = 2*q.q3*a.x;

				const float _2q0ay = 2*q.q0*a.y;
				const float _2q1ay = 2*q.q1*a.y;
				const float _2q2ay = 2*q.q2*a.y;
				const float _2q3ay = 2*q.q3*a.y;

				const float _2q0az = 2*q.q0*a.z;
				const float _2q1az = 2*q.q1*a.z;
				const float _2q2az = 2*q.q2*a.z;
				const float _2q3az = 2*q.q3*a.z;



				const float _2q0mx = 2*q.q0*m.x;
				const float _2q1mx = 2*q.q1*m.x;
				const float _2q2mx = 2*q.q2*m.x;
				const float _2q3mx = 2*q.q3*m.x;

				const float _2q0my = 2*q.q0*m.y;
				const float _2q1my = 2*q.q1*m.y;
				const float _2q2my = 2*q.q2*m.y;
				const float _2q3my = 2*q.q3*m.y;

				const float _2q0mz = 2*q.q0*m.z;
				const float _2q1mz = 2*q.q1*m.z;
				const float _2q2mz = 2*q.q2*m.z;
				const float _2q3mz = 2*q.q3*m.z;

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;


				arr[0][0] = _2q0ax + _2q3ay -_2q2az;
				arr[0][1] = _2q1ax + _2q2ay + _2q3az;
				arr[0][2] = -_2q2ax + _2q1ay - _2q0az;
				arr[0][3] = -_2q3ax + _2q0ay + _2q1az;
				arr[0][4] = q02 + q12 - q22 - q32;
				arr[0][5] = _2q1q2 + _2q0q3;
				arr[0][6] = _2q1q3 - _2q0q2;
				arr[0][7] = 0;
				arr[0][8] = 0;
				arr[0][9] = 0;

				arr[1][0] = -_2q3ax + _2q0ay +_2q1az;
				arr[1][1] = _2q2ax - _2q1ay +_2q0az;
				arr[1][2] = _2q1ax + _2q2ay +_2q3az;
				arr[1][3] = -_2q0ax - _2q3ay +_2q2az;
				arr[1][4] = _2q1q2 - _2q0q3;
				arr[1][5] = q02 - q12 + q22 - q32;
				arr[1][6] = _2q2q3 + _2q0q1;
				arr[1][7] = 0;
				arr[1][8] = 0;
				arr[1][9] = 0;

				arr[2][0] = _2q2ax - _2q1ay +_2q0az;
				arr[2][1] = _2q3ax - _2q0ay - _2q1az;
				arr[2][2] = _2q0ax + _2q3ay - _2q2az;
				arr[2][3] = _2q1ax + _2q2ay +_2q3az;
				arr[2][4] = _2q1q3 + _2q0q2;
				arr[2][5] = _2q2q3 - _2q0q1;
				arr[2][6] = q02 - q12 - q22 + q32;
				arr[2][7] = 0;
				arr[2][8] = 0;
				arr[2][9] = 0;


				arr[3][0] = 0;
				arr[3][1] = 0;
				arr[3][2] = 0;
				arr[3][3] = _2q0mx + _2q3my -_2q2mz;
				arr[3][4] = _2q1mx + _2q2my + _2q3mz;
				arr[3][5] = -_2q2mx + _2q1my - _2q0mz;
				arr[3][6] = -_2q3mx + _2q0my + _2q1mz;
				arr[3][7] = 0;
				arr[3][8] = 0;
				arr[3][9] = 0;

				arr[4][0] = 0;
				arr[4][1] = 0;
				arr[4][2] = 0;
				arr[4][3] = -_2q3mx + _2q0my +_2q1mz;
				arr[4][4] = _2q2mx - _2q1my +_2q0mz;
				arr[4][5] = _2q1mx + _2q2my +_2q3mz;
				arr[4][6] = -_2q0mx - _2q3my +_2q2mz;
				arr[4][7] = 0;
				arr[4][8] = 0;
				arr[4][9] = 0;

				arr[5][0] = 0;
				arr[5][1] = 0;
				arr[5][2] = 0;
				arr[5][3] = _2q2mx - _2q1my +_2q0mz;
				arr[5][4] = _2q3mx - _2q0my - _2q1mz;
				arr[5][5] = _2q0mx + _2q3my - _2q2mz;
				arr[5][6] = _2q1mx + _2q2my +_2q3mz;
				arr[5][7] = 0;
				arr[5][8] = 0;
				arr[5][9] = 0;
			};


			MatH(Quaternion_t q, Vector_t<float> a) : eMatrix(3,10) {


				const float _2q0ax = 2*q.q0*a.x;
				const float _2q1ax = 2*q.q1*a.x;
				const float _2q2ax = 2*q.q2*a.x;
				const float _2q3ax = 2*q.q3*a.x;

				const float _2q0ay = 2*q.q0*a.y;
				const float _2q1ay = 2*q.q1*a.y;
				const float _2q2ay = 2*q.q2*a.y;
				const float _2q3ay = 2*q.q3*a.y;

				const float _2q0az = 2*q.q0*a.z;
				const float _2q1az = 2*q.q1*a.z;
				const float _2q2az = 2*q.q2*a.z;
				const float _2q3az = 2*q.q3*a.z;

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;


				arr[0][0] = _2q0ax + _2q3ay -_2q2az;
				arr[0][1] = _2q1ax + _2q2ay + _2q3az;
				arr[0][2] = -_2q2ax + _2q1ay - _2q0az;
				arr[0][3] = -_2q3ax + _2q0ay + _2q1az;
				arr[0][4] = q02 + q12 - q22 - q32;
				arr[0][5] = _2q1q2 + _2q0q3;
				arr[0][6] = _2q1q3 - _2q0q2;
				arr[0][7] = 0;
				arr[0][8] = 0;
				arr[0][9] = 0;

				arr[1][0] = -_2q3ax + _2q0ay +_2q1az;
				arr[1][1] = _2q2ax - _2q1ay +_2q0az;
				arr[1][2] = _2q1ax + _2q2ay +_2q3az;
				arr[1][3] = -_2q0ax - _2q3ay +_2q2az;
				arr[1][4] = _2q1q2 - _2q0q3;
				arr[1][5] = q02 - q12 + q22 - q32;
				arr[1][6] = _2q2q3 + _2q0q1;
				arr[1][7] = 0;
				arr[1][8] = 0;
				arr[1][9] = 0;

				arr[2][0] = _2q2ax - _2q1ay +_2q0az;
				arr[2][1] = _2q3ax - _2q0ay - _2q1az;
				arr[2][2] = _2q0ax + _2q3ay - _2q2az;
				arr[2][3] = _2q1ax + _2q2ay +_2q3az;
				arr[2][4] = _2q1q3 + _2q0q2;
				arr[2][5] = _2q2q3 - _2q0q1;
				arr[2][6] = q02 - q12 - q22 + q32;
				arr[2][7] = 0;
				arr[2][8] = 0;
				arr[2][9] = 0;
			}
		};
	#else

		class MatH : public eMatrix
		{
		public:

			MatH(Quaternion_t q, Vector_t<float> a, Vector_t<float> m) : eMatrix(6,7) {

				const float _2q0ax = 2*q.q0*a.x;
				const float _2q1ax = 2*q.q1*a.x;
				const float _2q2ax = 2*q.q2*a.x;
				const float _2q3ax = 2*q.q3*a.x;

				const float _2q0ay = 2*q.q0*a.y;
				const float _2q1ay = 2*q.q1*a.y;
				const float _2q2ay = 2*q.q2*a.y;
				const float _2q3ay = 2*q.q3*a.y;

				const float _2q0az = 2*q.q0*a.z;
				const float _2q1az = 2*q.q1*a.z;
				const float _2q2az = 2*q.q2*a.z;
				const float _2q3az = 2*q.q3*a.z;



				const float _2q0mx = 2*q.q0*m.x;
				const float _2q1mx = 2*q.q1*m.x;
				const float _2q2mx = 2*q.q2*m.x;
				const float _2q3mx = 2*q.q3*m.x;

				const float _2q0my = 2*q.q0*m.y;
				const float _2q1my = 2*q.q1*m.y;
				const float _2q2my = 2*q.q2*m.y;
				const float _2q3my = 2*q.q3*m.y;

				const float _2q0mz = 2*q.q0*m.z;
				const float _2q1mz = 2*q.q1*m.z;
				const float _2q2mz = 2*q.q2*m.z;
				const float _2q3mz = 2*q.q3*m.z;

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;


				arr[0][0] = _2q0ax + _2q3ay -_2q2az;
				arr[0][1] = _2q1ax + _2q2ay + _2q3az;
				arr[0][2] = -_2q2ax + _2q1ay - _2q0az;
				arr[0][3] = -_2q3ax + _2q0ay + _2q1az;
				arr[0][4] = q02 + q12 - q22 - q32;
				arr[0][5] = _2q1q2 + _2q0q3;
				arr[0][6] = _2q1q3 - _2q0q2;

				arr[1][0] = -_2q3ax + _2q0ay +_2q1az;
				arr[1][1] = _2q2ax - _2q1ay +_2q0az;
				arr[1][2] = _2q1ax + _2q2ay +_2q3az;
				arr[1][3] = -_2q0ax - _2q3ay +_2q2az;
				arr[1][4] = _2q1q2 - _2q0q3;
				arr[1][5] = q02 - q12 + q22 - q32;
				arr[1][6] = _2q2q3 + _2q0q1;

				arr[2][0] = _2q2ax - _2q1ay +_2q0az;
				arr[2][1] = _2q3ax - _2q0ay - _2q1az;
				arr[2][2] = _2q0ax + _2q3ay - _2q2az;
				arr[2][3] = _2q1ax + _2q2ay +_2q3az;
				arr[2][4] = _2q1q3 + _2q0q2;
				arr[2][5] = _2q2q3 - _2q0q1;
				arr[2][6] = q02 - q12 - q22 + q32;


				arr[3][0] = 0;
				arr[3][1] = 0;
				arr[3][2] = 0;
				arr[3][3] = _2q0mx + _2q3my -_2q2mz;
				arr[3][4] = _2q1mx + _2q2my + _2q3mz;
				arr[3][5] = -_2q2mx + _2q1my - _2q0mz;
				arr[3][6] = -_2q3mx + _2q0my + _2q1mz;

				arr[4][0] = 0;
				arr[4][1] = 0;
				arr[4][2] = 0;
				arr[4][3] = -_2q3mx + _2q0my +_2q1mz;
				arr[4][4] = _2q2mx - _2q1my +_2q0mz;
				arr[4][5] = _2q1mx + _2q2my +_2q3mz;
				arr[4][6] = -_2q0mx - _2q3my +_2q2mz;

				arr[5][0] = 0;
				arr[5][1] = 0;
				arr[5][2] = 0;
				arr[5][3] = _2q2mx - _2q1my +_2q0mz;
				arr[5][4] = _2q3mx - _2q0my - _2q1mz;
				arr[5][5] = _2q0mx + _2q3my - _2q2mz;
				arr[5][6] = _2q1mx + _2q2my +_2q3mz;
			};


			MatH(Quaternion_t q, Vector_t<float> a) : eMatrix(3,7) {


				const float _2q0ax = 2*q.q0*a.x;
				const float _2q1ax = 2*q.q1*a.x;
				const float _2q2ax = 2*q.q2*a.x;
				const float _2q3ax = 2*q.q3*a.x;

				const float _2q0ay = 2*q.q0*a.y;
				const float _2q1ay = 2*q.q1*a.y;
				const float _2q2ay = 2*q.q2*a.y;
				const float _2q3ay = 2*q.q3*a.y;

				const float _2q0az = 2*q.q0*a.z;
				const float _2q1az = 2*q.q1*a.z;
				const float _2q2az = 2*q.q2*a.z;
				const float _2q3az = 2*q.q3*a.z;

				float q02 = q.q0*q.q0;
				float q12 = q.q1*q.q1;
				float q22 = q.q2*q.q2;
				float q32 = q.q3*q.q3;

				float _2q1q3 = 2*q.q1*q.q3;
				float _2q0q2 = 2*q.q0*q.q2;
				float _2q2q3 = 2*q.q2*q.q3;
				float _2q0q1 = 2*q.q0*q.q1;
				float _2q1q2 = 2*q.q1*q.q2;
				float _2q0q3 = 2*q.q0*q.q3;


				arr[0][0] = _2q0ax + _2q3ay -_2q2az;
				arr[0][1] = _2q1ax + _2q2ay + _2q3az;
				arr[0][2] = -_2q2ax + _2q1ay - _2q0az;
				arr[0][3] = -_2q3ax + _2q0ay + _2q1az;
				arr[0][4] = q02 + q12 - q22 - q32;
				arr[0][5] = _2q1q2 + _2q0q3;
				arr[0][6] = _2q1q3 - _2q0q2;

				arr[1][0] = -_2q3ax + _2q0ay +_2q1az;
				arr[1][1] = _2q2ax - _2q1ay +_2q0az;
				arr[1][2] = _2q1ax + _2q2ay +_2q3az;
				arr[1][3] = -_2q0ax - _2q3ay +_2q2az;
				arr[1][4] = _2q1q2 - _2q0q3;
				arr[1][5] = q02 - q12 + q22 - q32;
				arr[1][6] = _2q2q3 + _2q0q1;

				arr[2][0] = _2q2ax - _2q1ay +_2q0az;
				arr[2][1] = _2q3ax - _2q0ay - _2q1az;
				arr[2][2] = _2q0ax + _2q3ay - _2q2az;
				arr[2][3] = _2q1ax + _2q2ay +_2q3az;
				arr[2][4] = _2q1q3 + _2q0q2;
				arr[2][5] = _2q2q3 - _2q0q1;
				arr[2][6] = q02 - q12 - q22 + q32;
			}
		};

	#endif


#elif (USE_VEL_EST == 1)

class MatH : public eMatrix
{
public:

    MatH(Quaternion_t q, Vector_t<float> a, Vector_t<float> m) : eMatrix(6,7) {

        const float _2q0ax = 2*q.q0*a.x;
        const float _2q1ax = 2*q.q1*a.x;
        const float _2q2ax = 2*q.q2*a.x;
        const float _2q3ax = 2*q.q3*a.x;

        const float _2q0ay = 2*q.q0*a.y;
        const float _2q1ay = 2*q.q1*a.y;
        const float _2q2ay = 2*q.q2*a.y;
        const float _2q3ay = 2*q.q3*a.y;

        const float _2q0az = 2*q.q0*a.z;
        const float _2q1az = 2*q.q1*a.z;
        const float _2q2az = 2*q.q2*a.z;
        const float _2q3az = 2*q.q3*a.z;



        const float _2q0mx = 2*q.q0*m.x;
        const float _2q1mx = 2*q.q1*m.x;
        const float _2q2mx = 2*q.q2*m.x;
        const float _2q3mx = 2*q.q3*m.x;

        const float _2q0my = 2*q.q0*m.y;
        const float _2q1my = 2*q.q1*m.y;
        const float _2q2my = 2*q.q2*m.y;
        const float _2q3my = 2*q.q3*m.y;

        const float _2q0mz = 2*q.q0*m.z;
        const float _2q1mz = 2*q.q1*m.z;
        const float _2q2mz = 2*q.q2*m.z;
        const float _2q3mz = 2*q.q3*m.z;



        arr[0][0] = 0;
        arr[0][1] = 0;
        arr[0][2] = 0;
        arr[0][3] = _2q0ax + _2q3ay -_2q2az;
        arr[0][4] = _2q1ax + _2q2ay + _2q3az;
        arr[0][5] = -_2q2ax + _2q1ay - _2q0az;
        arr[0][6] = -_2q3ax + _2q0ay + _2q1az;

        arr[1][0] = 0;
        arr[1][1] = 0;
        arr[1][2] = 0;
        arr[1][3] = -_2q3ax + _2q0ay +_2q1az;
        arr[1][4] = _2q2ax - _2q1ay +_2q0az;
        arr[1][5] = _2q1ax + _2q2ay +_2q3az;
        arr[1][6] = -_2q0ax - _2q3ay +_2q2az;

        arr[2][0] = 0;
        arr[2][1] = 0;
        arr[2][2] = 0;
        arr[2][3] = _2q2ax - _2q1ay +_2q0az;
        arr[2][4] = _2q3ax - _2q0ay - _2q1az;
        arr[2][5] = _2q0ax + _2q3ay - _2q2az;
        arr[2][6] = _2q1ax + _2q2ay +_2q3az;



        arr[3][0] = 0;
        arr[3][1] = 0;
        arr[3][2] = 0;
        arr[3][3] = _2q0mx + _2q3my -_2q2mz;
        arr[3][4] = _2q1mx + _2q2my + _2q3mz;
        arr[3][5] = -_2q2mx + _2q1my - _2q0mz;
        arr[3][6] = -_2q3mx + _2q0my + _2q1mz;

        arr[4][0] = 0;
        arr[4][1] = 0;
        arr[4][2] = 0;
        arr[4][3] = -_2q3mx + _2q0my +_2q1mz;
        arr[4][4] = _2q2mx - _2q1my +_2q0mz;
        arr[4][5] = _2q1mx + _2q2my +_2q3mz;
        arr[4][6] = -_2q0mx - _2q3my +_2q2mz;

        arr[5][0] = 0;
        arr[5][1] = 0;
        arr[5][2] = 0;
        arr[5][3] = _2q2mx - _2q1my +_2q0mz;
        arr[5][4] = _2q3mx - _2q0my - _2q1mz;
        arr[5][5] = _2q0mx + _2q3my - _2q2mz;
        arr[5][6] = _2q1mx + _2q2my +_2q3mz;
    };


    MatH(Quaternion_t q, Vector_t<float> a) : eMatrix(3,7) {

        const float _2q0ax = 2*q.q0*a.x;
        const float _2q1ax = 2*q.q1*a.x;
        const float _2q2ax = 2*q.q2*a.x;
        const float _2q3ax = 2*q.q3*a.x;

        const float _2q0ay = 2*q.q0*a.y;
        const float _2q1ay = 2*q.q1*a.y;
        const float _2q2ay = 2*q.q2*a.y;
        const float _2q3ay = 2*q.q3*a.y;

        const float _2q0az = 2*q.q0*a.z;
        const float _2q1az = 2*q.q1*a.z;
        const float _2q2az = 2*q.q2*a.z;
        const float _2q3az = 2*q.q3*a.z;



        arr[0][0] = 0;
        arr[0][1] = 0;
        arr[0][2] = 0;
        arr[0][3] = _2q0ax + _2q3ay -_2q2az;
        arr[0][4] = _2q1ax + _2q2ay + _2q3az;
        arr[0][5] = -_2q2ax + _2q1ay - _2q0az;
        arr[0][6] = -_2q3ax + _2q0ay + _2q1az;

        arr[1][0] = 0;
        arr[1][1] = 0;
        arr[1][2] = 0;
        arr[1][3] = -_2q3ax + _2q0ay +_2q1az;
        arr[1][4] = _2q2ax - _2q1ay +_2q0az;
        arr[1][5] = _2q1ax + _2q2ay +_2q3az;
        arr[1][6] = -_2q0ax - _2q3ay +_2q2az;

        arr[2][0] = 0;
        arr[2][1] = 0;
        arr[2][2] = 0;
        arr[2][3] = _2q2ax - _2q1ay +_2q0az;
        arr[2][4] = _2q3ax - _2q0ay - _2q1az;
        arr[2][5] = _2q0ax + _2q3ay - _2q2az;
        arr[2][6] = _2q1ax + _2q2ay +_2q3az;
    }
};

#elif (USE_GYRO_BIAS == 1)

class MatH : public eMatrix
{
public:

    MatH(Quaternion_t q, Vector_t<float> g, Vector_t<float> m) : eMatrix(6,7) {

        const float _2q0g = -2*q.q0*g.z;
        const float _2q1g = -2*q.q1*g.z;
        const float _2q2g = -2*q.q2*g.z;
        const float _2q3g = -2*q.q3*g.z;

        const float _2q0mx = 2*q.q0*m.x;
        const float _2q1mx = 2*q.q1*m.x;
        const float _2q2mx = 2*q.q2*m.x;
        const float _2q3mx = 2*q.q3*m.x;

        const float _2q0my = 2*q.q0*m.y;
        const float _2q1my = 2*q.q1*m.y;
        const float _2q2my = 2*q.q2*m.y;
        const float _2q3my = 2*q.q3*m.y;

        const float _2q0mz = 2*q.q0*m.z;
        const float _2q1mz = 2*q.q1*m.z;
        const float _2q2mz = 2*q.q2*m.z;
        const float _2q3mz = 2*q.q3*m.z;

        arr[0][0] = _2q2g;
        arr[0][1] = -_2q3g;
        arr[0][2] = _2q0g;
        arr[0][3] = -_2q1g;
        arr[0][4] = 0;
        arr[0][5] = 0;
        arr[0][6] = 0;

        arr[1][0] = -_2q1g;
        arr[1][1] = -_2q0g;
        arr[1][2] = -_2q3g;
        arr[1][3] = -_2q2g;
        arr[1][4] = 0;
        arr[1][5] = 0;
        arr[1][6] = 0;

        arr[2][0] = -_2q0g;
        arr[2][1] = _2q1g;
        arr[2][2] = _2q2g;
        arr[2][3] = -_2q3g;
        arr[2][4] = 0;
        arr[2][5] = 0;
        arr[2][6] = 0;
        //

        arr[3][0] = _2q0mx + _2q3my -_2q2mz;
        arr[3][1] = _2q1mx + _2q2my + _2q3mz;
        arr[3][2] = -_2q2mx + _2q1my - _2q0mz;
        arr[3][3] = -_2q3mx + _2q0my + _2q1mz;
        arr[3][4] = 0;
        arr[3][5] = 0;
        arr[3][6] = 0;


        arr[4][0] = -_2q3mx + _2q0my +_2q1mz;
        arr[4][1] = _2q2mx - _2q1my +_2q0mz;;
        arr[4][2] = _2q1mx + _2q2my +_2q3mz;;
        arr[4][3] = -_2q0mx - _2q3my +_2q2mz;;
        arr[4][4] = 0;
        arr[4][5] = 0;
        arr[4][6] = 0;


        arr[5][0] = _2q2mx - _2q1my +_2q0mz;
        arr[5][1] = _2q3mx - _2q0my - _2q1mz;
        arr[5][2] = _2q0mx + _2q3my - _2q2mz;
        arr[5][3] = _2q1mx + _2q2my +_2q3mz;
        arr[5][4] = 0;
        arr[5][5] = 0;
        arr[5][6] = 0;
    };

    MatH(Quaternion_t q, Vector_t<float> g) : eMatrix(3,7) {

        const float _2q0g = -2*q.q0*g.z;
        const float _2q1g = -2*q.q1*g.z;
        const float _2q2g = -2*q.q2*g.z;
        const float _2q3g = -2*q.q3*g.z;

        arr[0][0] = _2q2g;
        arr[0][1] = -_2q3g;
        arr[0][2] = _2q0g;
        arr[0][3] = -_2q1g;
        arr[0][4] = 0;
        arr[0][5] = 0;
        arr[0][6] = 0;

        arr[1][0] = -_2q1g;
        arr[1][1] = -_2q0g;
        arr[1][2] = -_2q3g;
        arr[1][3] = -_2q2g;
        arr[1][4] = 0;
        arr[1][5] = 0;
        arr[1][6] = 0;

        arr[2][0] = -_2q0g;
        arr[2][1] = _2q1g;
        arr[2][2] = _2q2g;
        arr[2][3] = -_2q3g;
        arr[2][4] = 0;
        arr[2][5] = 0;
        arr[2][6] = 0;
    };


};

//#else

//class MatH : public eMatrix
//{
//public:
//
//    MatH(Quaternion_t q, Vector_t<float> g, Vector_t<float> m) : eMatrix(6,7) {
//
//        const float _2q0g = 2*q.q0*g.z;
//        const float _2q1g = 2*q.q1*g.z;
//        const float _2q2g = 2*q.q2*g.z;
//        const float _2q3g = 2*q.q3*g.z;
//
//        const float _2q0mx = 2*q.q0*m.x;
//        const float _2q1mx = 2*q.q1*m.x;
//        const float _2q2mx = 2*q.q2*m.x;
//        const float _2q3mx = 2*q.q3*m.x;
//
//        const float _2q0my = 2*q.q0*m.y;
//        const float _2q1my = 2*q.q1*m.y;
//        const float _2q2my = 2*q.q2*m.y;
//        const float _2q3my = 2*q.q3*m.y;
//
//        const float _2q0mz = 2*q.q0*m.z;
//        const float _2q1mz = 2*q.q1*m.z;
//        const float _2q2mz = 2*q.q2*m.z;
//        const float _2q3mz = 2*q.q3*m.z;
//
//        arr[0][0] = _2q2g;
//        arr[0][1] = -_2q3g;
//        arr[0][2] = _2q0g;
//        arr[0][3] = -_2q1g;
//        arr[0][4] = 0;
//        arr[0][5] = 0;
//        arr[0][6] = 0;
//
//        arr[1][0] = -_2q1g;
//        arr[1][1] = -_2q0g;
//        arr[1][2] = -_2q3g;
//        arr[1][3] = -_2q2g;
//        arr[1][4] = 0;
//        arr[1][5] = 0;
//        arr[1][6] = 0;
//
//        arr[2][0] = -_2q0g;
//        arr[2][1] = _2q1g;
//        arr[2][2] = _2q2g;
//        arr[2][3] = -_2q3g;
//        arr[2][4] = 0;
//        arr[2][5] = 0;
//        arr[2][6] = 0;
//        //
//
//        arr[3][0] = _2q0mx + _2q3my -_2q2mz;
//        arr[3][1] = _2q1mx + _2q2my + _2q3mz;
//        arr[3][2] = -_2q2mx + _2q1my - _2q0mz;
//        arr[3][3] = -_2q3mx + _2q0my + _2q1mz;
//        arr[3][4] = 0;
//        arr[3][5] = 0;
//        arr[3][6] = 0;
//
//
//        arr[4][0] = -_2q3mx + _2q0my +_2q1mz;
//        arr[4][1] = _2q2mx - _2q1my +_2q0mz;;
//        arr[4][2] = _2q1mx + _2q2my +_2q3mz;;
//        arr[4][3] = -_2q0mx - _2q3my +_2q2mz;;
//        arr[4][4] = 0;
//        arr[4][5] = 0;
//        arr[4][6] = 0;
//
//
//        arr[5][0] = _2q2mx - _2q1my +_2q0mz;
//        arr[5][1] = _2q3mx - _2q0my - _2q1mz;
//        arr[5][2] = _2q0mx + _2q3my - _2q2mz;
//        arr[5][3] = _2q1mx + _2q2my +_2q3mz;
//        arr[5][4] = 0;
//        arr[5][5] = 0;
//        arr[5][6] = 0;
//    };
//
//    MatH(Quaternion_t q, Vector_t<float> g) : eMatrix(3,7) {
//
//        const float _2q0g = 2*q.q0*g.z;
//        const float _2q1g = 2*q.q1*g.z;
//        const float _2q2g = 2*q.q2*g.z;
//        const float _2q3g = 2*q.q3*g.z;
//
//        arr[0][0] = _2q2g;
//        arr[0][1] = -_2q3g;
//        arr[0][2] = _2q0g;
//        arr[0][3] = -_2q1g;
//        arr[0][4] = 0;
//        arr[0][5] = 0;
//        arr[0][6] = 0;
//
//        arr[1][0] = -_2q1g;
//        arr[1][1] = -_2q0g;
//        arr[1][2] = -_2q3g;
//        arr[1][3] = -_2q2g;
//        arr[1][4] = 0;
//        arr[1][5] = 0;
//        arr[1][6] = 0;
//
//        arr[2][0] = -_2q0g;
//        arr[2][1] = _2q1g;
//        arr[2][2] = _2q2g;
//        arr[2][3] = -_2q3g;
//        arr[2][4] = 0;
//        arr[2][5] = 0;
//        arr[2][6] = 0;
//    };
//
//
//};
//#endif

#else

class MatH : public eMatrix
{
public:

    MatH(Quaternion_t q, Vector_t<float> g, Vector_t<float> m) : eMatrix(6,4) {

        const float _2q0g = -2*q.q0*g.z;
        const float _2q1g = -2*q.q1*g.z;
        const float _2q2g = -2*q.q2*g.z;
        const float _2q3g = -2*q.q3*g.z;

        const float _2q0mx = 2*q.q0*m.x;
        const float _2q1mx = 2*q.q1*m.x;
        const float _2q2mx = 2*q.q2*m.x;
        const float _2q3mx = 2*q.q3*m.x;

        const float _2q0my = 2*q.q0*m.y;
        const float _2q1my = 2*q.q1*m.y;
        const float _2q2my = 2*q.q2*m.y;
        const float _2q3my = 2*q.q3*m.y;

        const float _2q0mz = 2*q.q0*m.z;
        const float _2q1mz = 2*q.q1*m.z;
        const float _2q2mz = 2*q.q2*m.z;
        const float _2q3mz = 2*q.q3*m.z;

        arr[0][0] = _2q2g;
        arr[0][1] = -_2q3g;
        arr[0][2] = _2q0g;
        arr[0][3] = -_2q1g;
        arr[0][4] = 0;
        arr[0][5] = 0;
        arr[0][6] = 0;

        arr[1][0] = -_2q1g;
        arr[1][1] = -_2q0g;
        arr[1][2] = -_2q3g;
        arr[1][3] = -_2q2g;

        arr[2][0] = -_2q0g;
        arr[2][1] = _2q1g;
        arr[2][2] = _2q2g;
        arr[2][3] = -_2q3g;

        arr[3][0] = _2q0mx + _2q3my -_2q2mz;
        arr[3][1] = _2q1mx + _2q2my + _2q3mz;
        arr[3][2] = -_2q2mx + _2q1my - _2q0mz;
        arr[3][3] = -_2q3mx + _2q0my + _2q1mz;


        arr[4][0] = -_2q3mx + _2q0my +_2q1mz;
        arr[4][1] = _2q2mx - _2q1my +_2q0mz;;
        arr[4][2] = _2q1mx + _2q2my +_2q3mz;;
        arr[4][3] = -_2q0mx - _2q3my +_2q2mz;


        arr[5][0] = _2q2mx - _2q1my +_2q0mz;
        arr[5][1] = _2q3mx - _2q0my - _2q1mz;
        arr[5][2] = _2q0mx + _2q3my - _2q2mz;
        arr[5][3] = _2q1mx + _2q2my +_2q3mz;
    };

    MatH(Quaternion_t q, Vector_t<float> g) : eMatrix(3,4) {

        const float _2q0g = -2*q.q0*g.z;
        const float _2q1g = -2*q.q1*g.z;
        const float _2q2g = -2*q.q2*g.z;
        const float _2q3g = -2*q.q3*g.z;

        arr[0][0] = _2q2g;
        arr[0][1] = -_2q3g;
        arr[0][2] = _2q0g;
        arr[0][3] = -_2q1g;

        arr[1][0] = -_2q1g;
        arr[1][1] = -_2q0g;
        arr[1][2] = -_2q3g;
        arr[1][3] = -_2q2g;

        arr[2][0] = -_2q0g;
        arr[2][1] = _2q1g;
        arr[2][2] = _2q2g;
        arr[2][3] = -_2q3g;
    };


};
#endif


#if (USE_ACC_EST == 1)

	#if (USE_GYRO_BIAS == 1)

		class MatF : public eMatrix
		{
		public:
		//	float dT = 0.001;

			MatF(Quaternion_t q,Vector_t<float> gyro, Vector_t<float> b, float dT) : eMatrix(10,10) {
		//        eMatrix(7,7);
				float _05dT = 0.5*dT;

				arr[0][0] = 1;
				arr[0][1] = -_05dT*(gyro.x-b.x);
				arr[0][2] = -_05dT*(gyro.y-b.y);
				arr[0][3] = -_05dT*(gyro.z-b.z);
				arr[0][4] = 0;
				arr[0][5] = 0;
				arr[0][6] = 0;
				arr[0][7] = _05dT*q.q1;
				arr[0][8] = _05dT*q.q2;
				arr[0][9] = _05dT*q.q3;

				arr[1][0] = _05dT*(gyro.x-b.x);
				arr[1][1] = 1;
				arr[1][2] = _05dT*(gyro.z-b.z);
				arr[1][3] = -_05dT*(gyro.y-b.y);
				arr[1][4] = 0;
				arr[1][5] = 0;
				arr[1][6] = 0;
				arr[1][7] = -_05dT*q.q0;
				arr[1][8] = _05dT*q.q3;
				arr[1][9] = -_05dT*q.q2;

				arr[2][0] = _05dT*(gyro.y-b.y);
				arr[2][1] = -_05dT*(gyro.z-b.z);
				arr[2][2] = 1;
				arr[2][3] = _05dT*(gyro.x-b.x);
				arr[2][4] = 0;
				arr[2][5] = 0;
				arr[2][6] = 0;
				arr[2][7] = -_05dT*q.q3;
				arr[2][8] = -_05dT*q.q0;
				arr[2][9] = _05dT*q.q1;
				//

				arr[3][0] = _05dT*(gyro.z-b.z);
				arr[3][1] = _05dT*(gyro.y-b.y);
				arr[3][2] = -_05dT*(gyro.x-b.x);
				arr[3][3] = 1;
				arr[3][4] = 0;
				arr[3][5] = 0;
				arr[3][6] = 0;
				arr[3][7] = _05dT*q.q2;
				arr[3][8] = -_05dT*q.q1;
				arr[3][9] = -_05dT*q.q0;


				arr[4][0] = 0;
				arr[4][1] = 0;
				arr[4][2] = 0;
				arr[4][3] = 0;
				arr[4][4] = 1;
				arr[4][5] = 0;
				arr[4][6] = 0;
				arr[4][7] = 0;
				arr[4][8] = 0;
				arr[4][9] = 0;

				arr[5][0] = 0;
				arr[5][1] = 0;
				arr[5][2] = 0;
				arr[5][3] = 0;
				arr[5][4] = 0;
				arr[5][5] = 1;
				arr[5][6] = 0;
				arr[5][7] = 0;
				arr[5][8] = 0;
				arr[5][9] = 0;

				arr[6][0] = 0;
				arr[6][1] = 0;
				arr[6][2] = 0;
				arr[6][3] = 0;
				arr[6][4] = 0;
				arr[6][5] = 0;
				arr[6][6] = 1;
				arr[6][7] = 0;
				arr[6][8] = 0;
				arr[6][9] = 0;

				arr[7][0] = 0;
				arr[7][1] = 0;
				arr[7][2] = 0;
				arr[7][3] = 0;
				arr[7][4] = 0;
				arr[7][5] = 0;
				arr[7][6] = 0;
				arr[7][7] = 1;
				arr[7][8] = 0;
				arr[7][9] = 0;

				arr[8][0] = 0;
				arr[8][1] = 0;
				arr[8][2] = 0;
				arr[8][3] = 0;
				arr[8][4] = 0;
				arr[8][5] = 0;
				arr[8][6] = 0;
				arr[8][7] = 0;
				arr[8][8] = 1;
				arr[8][9] = 0;

				arr[9][0] = 0;
				arr[9][1] = 0;
				arr[9][2] = 0;
				arr[9][3] = 0;
				arr[9][4] = 0;
				arr[9][5] = 0;
				arr[9][6] = 0;
				arr[9][7] = 0;
				arr[9][8] = 0;
				arr[9][9] = 1;
			};


		};

	#else

		class MatF : public eMatrix
		{
		public:
		//	float dT = 0.001;

			MatF(Vector_t<float> gyro, float dT) : eMatrix(7,7) {
		//        eMatrix(7,7);
				float _05dT = 0.5*dT;

				arr[0][0] = 0;
				arr[0][1] = -_05dT*gyro.x;
				arr[0][2] = -_05dT*gyro.y;
				arr[0][3] = -_05dT*gyro.z;
				arr[0][4] = 0;
				arr[0][5] = 0;
				arr[0][6] = 0;

				arr[1][0] = _05dT*gyro.x;
				arr[1][1] = 0;
				arr[1][2] = _05dT*gyro.z;
				arr[1][3] = -_05dT*gyro.y;
				arr[1][4] = 0;
				arr[1][5] = 0;
				arr[1][6] = 0;

				arr[2][0] = _05dT*gyro.y;
				arr[2][1] = -_05dT*gyro.z;
				arr[2][2] = 0;
				arr[2][3] = _05dT*gyro.x;
				arr[2][4] = 0;
				arr[2][5] = 0;
				arr[2][6] = 0;
				//

				arr[3][0] = _05dT*gyro.z;
				arr[3][1] = _05dT*gyro.y;
				arr[3][2] = -_05dT*gyro.x;
				arr[3][3] = 0;
				arr[3][4] = 0;
				arr[3][5] = 0;
				arr[3][6] = 0;


				arr[4][0] = 0;
				arr[4][1] = 0;
				arr[4][2] = 0;
				arr[4][3] = 0;
				arr[4][4] = 1;
				arr[4][5] = 0;
				arr[4][6] = 0;


				arr[5][0] = 0;
				arr[5][1] = 0;
				arr[5][2] = 0;
				arr[5][3] = 0;
				arr[5][4] = 0;
				arr[5][5] = 1;
				arr[5][6] = 0;

				arr[6][0] = 0;
				arr[6][1] = 0;
				arr[6][2] = 0;
				arr[6][3] = 0;
				arr[6][4] = 0;
				arr[6][5] = 0;
				arr[6][6] = 1;
			};

		};
	#endif


#elif (USE_VEL_EST == 1)

class MatF : public eMatrix
{
public:

//    MatF(Vector_t<float> gyro, float dT) : eMatrix(7,7) {
//    	float _05dT = 0.5*dT;
//
//        arr[0][0] = 1;
//        arr[0][1] = 0;
//        arr[0][2] = 0;
//        arr[0][3] = 0;
//        arr[0][4] = 0;
//        arr[0][5] = 0;
//        arr[0][6] = 0;
//
//        arr[1][0] = 0;
//        arr[1][1] = 1;
//        arr[1][2] = 0;
//        arr[1][3] = 0;
//        arr[1][4] = 0;
//        arr[1][5] = 0;
//        arr[1][6] = 0;
//
//        arr[2][0] = 0;
//        arr[2][1] = 0;
//        arr[2][2] = 1;
//        arr[2][3] = 0;
//        arr[2][4] = 0;
//        arr[2][5] = 0;
//        arr[2][6] = 0;
//
//
//
//
//        arr[3][0] = 0;
//        arr[3][1] = 0;
//        arr[3][2] = 0;
//        arr[3][3] = 1;
//        arr[3][4] = 1 - _05dT*(gyro.x);
//        arr[3][5] = 1 - _05dT*(gyro.y);
//        arr[3][6] = 1 - _05dT*(gyro.z);
//
//        arr[4][0] = 0;
//        arr[4][1] = 0;
//        arr[4][2] = 0;
//        arr[4][3] = 1 + _05dT*(gyro.x);
//        arr[4][4] = 1;
//        arr[4][5] = 1 + _05dT*(gyro.z);
//        arr[4][6] = 1 -_05dT*(gyro.y);
//
//        arr[5][0] = 0;
//        arr[5][1] = 0;
//        arr[5][2] = 0;
//        arr[5][3] = 1 + _05dT*(gyro.y);
//        arr[5][4] = 1 - _05dT*(gyro.z);
//        arr[5][5] = 1;
//        arr[5][6] = 1 + _05dT*(gyro.x);
//        //
//
//        arr[6][0] = 0;
//        arr[6][1] = 0;
//        arr[6][2] = 0;
//        arr[6][3] = 1 + _05dT*(gyro.z);
//        arr[6][4] = 1 + _05dT*(gyro.y);
//        arr[6][5] = 1 -_05dT*(gyro.x);
//        arr[6][6] = 1;
//    };

    MatF(Quaternion_t q, Vector_t<float> a, Vector_t<float> gyro, float dT) : eMatrix(7,7) {
    	float _05dT = 0.5*dT;
    	float axq0 = 2*a.x*q.q0;
    	float axq1 = 2*a.x*q.q1;
    	float axq2 = 2*a.x*q.q2;
    	float axq3 = 2*a.x*q.q3;

    	float ayq0 = 2*a.y*q.q0;
    	float ayq1 = 2*a.y*q.q1;
    	float ayq2 = 2*a.y*q.q2;
    	float ayq3 = 2*a.y*q.q3;

    	float azq0 = 2*a.z*q.q0;
    	float azq1 = 2*a.z*q.q1;
    	float azq2 = 2*a.z*q.q2;
    	float azq3 = 2*a.z*q.q3;

        arr[0][0] = 0;
        arr[0][1] = 0;
        arr[0][2] = 0;
        arr[0][3] = 0;
        arr[0][4] = -_05dT*(gyro.x);
        arr[0][5] = -_05dT*(gyro.y);
        arr[0][6] = -_05dT*(gyro.z);

        arr[1][0] = 0;
        arr[1][1] = 0;
        arr[1][2] = 0;
        arr[1][3] = _05dT*(gyro.x);
        arr[1][4] = 0;
        arr[1][5] = _05dT*(gyro.z);
        arr[1][6] = -_05dT*(gyro.y);

        arr[2][0] = 0;
        arr[2][1] = 0;
        arr[2][2] = 0;
        arr[2][3] = _05dT*(gyro.y);
        arr[2][4] = -_05dT*(gyro.z);
        arr[2][5] = 0;
        arr[2][6] = _05dT*(gyro.x);
        //

        arr[3][0] = 0;
        arr[3][1] = 0;
        arr[3][2] = 0;
        arr[3][3] = _05dT*(gyro.z);
        arr[3][4] = _05dT*(gyro.y);
        arr[3][5] = -_05dT*(gyro.x);
        arr[3][6] = 0;

//        arr[4][0] = 0;
//        arr[4][1] = 0;
//        arr[4][2] = 0;
//        arr[4][3] = axq0 + ayq3 - azq2;
//        arr[4][4] = axq1 + ayq2 + azq3;
//        arr[4][5] = -axq2 + ayq1 - azq0;
//        arr[4][6] = axq3 + ayq0 + azq1;
//
//        arr[5][0] = 0;
//        arr[5][1] = 0;
//        arr[5][2] = 0;
//        arr[5][3] = -axq3 + ayq0 + azq1;
//        arr[5][4] = axq2 - ayq1 + azq0;
//        arr[5][5] = axq1 + ayq2 + azq3;
//        arr[5][6] = axq0 + ayq3 - azq2;
//
//        arr[6][0] = 0;
//        arr[6][1] = 0;
//        arr[6][2] = 0;
//        arr[6][3] = axq2 - ayq1 + azq0;
//        arr[6][4] = -axq1 - ayq2 - azq3;
//        arr[6][5] = axq0 + ayq3 - azq2;
//        arr[6][6] = -axq3 + ayq0 + azq1;

        arr[4][0] = 0;
        arr[4][1] = 0;
        arr[4][2] = 0;
        arr[4][3] = axq0 - ayq3 + azq2;
        arr[4][4] = axq1 + ayq2 + azq3;
        arr[4][5] = -axq2 + ayq1 + azq0;
        arr[4][6] = -axq3 - ayq0 + azq1;

        arr[5][0] = 0;
        arr[5][1] = 0;
        arr[5][2] = 0;
        arr[5][3] = axq3 + ayq0 - azq1;
        arr[5][4] = axq2 - ayq1 - azq0;
        arr[5][5] = axq1 + ayq2 + azq3;
        arr[5][6] = axq0 - ayq3 + azq2;

        arr[6][0] = 0;
        arr[6][1] = 0;
        arr[6][2] = 0;
        arr[6][3] = -axq2 + ayq1 + azq0;
        arr[6][4] = axq3 + ayq0 - azq1;
        arr[6][5] = -axq0 + ayq3 - azq2;
        arr[6][6] = axq1 + ayq2 + azq3;
    };


};

#elif (USE_GYRO_BIAS == 1)

class MatF : public eMatrix
{
public:
//	float dT = 0.001;

    MatF(Quaternion_t q,Vector_t<float> gyro, Vector_t<float> b, float dT) : eMatrix(7,7) {
//        eMatrix(7,7);
    	float _05dT = 0.5*dT;

        arr[0][0] = 1;
        arr[0][1] = -_05dT*(gyro.x-b.x);
        arr[0][2] = -_05dT*(gyro.y-b.y);
        arr[0][3] = -_05dT*(gyro.z-b.z);
        arr[0][4] = _05dT*q.q1;
        arr[0][5] = _05dT*q.q2;
        arr[0][6] = _05dT*q.q3;

        arr[1][0] = _05dT*(gyro.x-b.x);
        arr[1][1] = 1;
        arr[1][2] = _05dT*(gyro.z-b.z);
        arr[1][3] = -_05dT*(gyro.y-b.y);
//        arr[1][4] = -_05dT*q.q0;
//        arr[1][5] = _05dT*q.q3;
//        arr[1][6] = -_05dT*q.q2;
        arr[1][4] = -_05dT*q.q0;
        arr[1][5] = _05dT*q.q3;
        arr[1][6] = -_05dT*q.q2;

        arr[2][0] = _05dT*(gyro.y-b.y);
        arr[2][1] = -_05dT*(gyro.z-b.z);
        arr[2][2] = 1;
        arr[2][3] = _05dT*(gyro.x-b.x);
//        arr[2][4] = -_05dT*q.q3;
//        arr[2][5] = -_05dT*q.q0;
//        arr[2][6] = _05dT*q.q1;

        arr[2][4] = -_05dT*q.q3;
        arr[2][5] = -_05dT*q.q0;
        arr[2][6] = _05dT*q.q1;
        //

        arr[3][0] = _05dT*(gyro.z-b.z);
        arr[3][1] = _05dT*(gyro.y-b.y);
        arr[3][2] = -_05dT*(gyro.x-b.x);
        arr[3][3] = 1;
//        arr[3][4] = _05dT*q.q2;
//        arr[3][5] = -_05dT*q.q1;
//        arr[3][6] = -_05dT*q.q0;

        arr[3][4] = _05dT*q.q2;
        arr[3][5] = -_05dT*q.q1;
        arr[3][6] = -_05dT*q.q0;


        arr[4][0] = 0;
        arr[4][1] = 0;
        arr[4][2] = 0;
        arr[4][3] = 0;
        arr[4][4] = 1;
        arr[4][5] = 0;
        arr[4][6] = 0;


        arr[5][0] = 0;
        arr[5][1] = 0;
        arr[5][2] = 0;
        arr[5][3] = 0;
        arr[5][4] = 0;
        arr[5][5] = 1;
        arr[5][6] = 0;

        arr[6][0] = 0;
        arr[6][1] = 0;
        arr[6][2] = 0;
        arr[6][3] = 0;
        arr[6][4] = 0;
        arr[6][5] = 0;
        arr[6][6] = 1;
    };


};

#else

class MatF : public eMatrix
{
public:
//	float dT = 0.001;

    MatF(Vector_t<float> gyro, float dT) : eMatrix(4,4) {
//        eMatrix(7,7);
    	float _05dT = 0.5*dT;

        arr[0][0] = 1;
        arr[0][1] = -_05dT*(gyro.x);
        arr[0][2] = -_05dT*(gyro.y);
        arr[0][3] = -_05dT*(gyro.z);

        arr[1][0] = _05dT*(gyro.x);
        arr[1][1] = 1;
        arr[1][2] = _05dT*(gyro.z);
        arr[1][3] = -_05dT*(gyro.y);

        arr[2][0] = _05dT*(gyro.y);
        arr[2][1] = -_05dT*(gyro.z);
        arr[2][2] = 1;
        arr[2][3] = _05dT*(gyro.x);
        //

        arr[3][0] = _05dT*(gyro.z);
        arr[3][1] = _05dT*(gyro.y);
        arr[3][2] = -_05dT*(gyro.x);
        arr[3][3] = 1;
    };


};

#endif


//class MatF : public eMatrix
//{
//public:
////	float dT = 0.001;
//
//    MatF(Quaternion_t q,Vector_t<float> gyro, Vector_t<float> b, float dT) : eMatrix(7,7) {
////        eMatrix(7,7);
//    	float _05dT = 0.5*dT;
//
//        arr[0][0] = 1;
//        arr[0][1] = -_05dT*(gyro.x-b.x);
//        arr[0][2] = -_05dT*(gyro.y-b.y);
//        arr[0][3] = -_05dT*(gyro.z-b.z);
//        arr[0][4] = 0;
//        arr[0][5] = 0;
//        arr[0][6] = 0;
//
//        arr[1][0] = _05dT*(gyro.x-b.x);
//        arr[1][1] = 1;
//        arr[1][2] = _05dT*(gyro.z-b.z);
//        arr[1][3] = -_05dT*(gyro.y-b.y);
//        arr[1][4] = 0;
//        arr[1][5] = 0;
//        arr[1][6] = 0;
//
//        arr[2][0] = _05dT*(gyro.y-b.y);
//        arr[2][1] = -_05dT*(gyro.z-b.z);
//        arr[2][2] = 1;
//        arr[2][3] = _05dT*(gyro.x-b.x);
//        arr[2][4] = 0;
//        arr[2][5] = 0;
//        arr[2][6] = 0;
//        //
//
//        arr[3][0] = _05dT*(gyro.z-b.z);
//        arr[3][1] = _05dT*(gyro.y-b.y);
//        arr[3][2] = -_05dT*(gyro.x-b.x);
//        arr[3][3] = 1;
//        arr[3][4] = 0;
//        arr[3][5] = 0;
//        arr[3][6] = 0;
//
//
//        arr[4][0] = 0;
//        arr[4][1] = -_05dT*q.q1;
//        arr[4][2] = -_05dT*q.q2;
//        arr[4][3] = -_05dT*q.q3;
//        arr[4][4] = 1;
//        arr[4][5] = 0;
//        arr[4][6] = 0;
//
//
//        arr[5][0] = 0;
//        arr[5][1] = _05dT*q.q0;
//        arr[5][2] = _05dT*q.q3;
//        arr[5][3] = -_05dT*q.q2;
//        arr[5][4] = 0;
//        arr[5][5] = 1;
//        arr[5][6] = 0;
//
//        arr[6][0] = 0;
//        arr[6][1] = _05dT*q.q3;
//        arr[6][2] = _05dT*q.q0;
//        arr[6][3] = -_05dT*q.q1;
//        arr[6][4] = 0;
//        arr[6][5] = 0;
//        arr[6][6] = 1;
//    };
//
//
//};

#endif /* EKF_EKF_H_ */
