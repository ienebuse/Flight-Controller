/*
 * iMatrix.h
 *
 *  Created on: Jul 24, 2024
 *      Author: ienebuse
 */

#ifndef EKF_EKFMATH_IMATRIX_H_
#define EKF_EKFMATH_IMATRIX_H_

#include <stdint.h>
#include <assert.h>
#include <array>
#include <eVector.h>
#include <typedefs.h>

#define MAT_MAX_SIZE	6



//typedef struct {
//    float x=0, y=0, z=0;
//}Vector_t;


class eMatrix {

public:
    float arr[MAT_MAX_SIZE][MAT_MAX_SIZE];
    uint8_t rows, columns;


//    eMatrix();
//    virtual ~eMatrix();

    eMatrix(uint8_t row, uint8_t col) : rows(row), columns(col) {
    	for(uint8_t row = 0; row < rows; row++) {
    		for(uint8_t col = 0; col < columns; col++) {
    			arr[row][col] =  0;
    		}
		}
    }

    eMatrix(uint8_t row, uint8_t col, float diag) : rows(row), columns(col) {
        for(uint8_t row = 0; row < rows; row++) {
                arr[row][row] =  diag;
        }
    }

    inline eMatrix operator +(const eMatrix &mat) {
        assert(mat.rows == rows && mat.columns == columns);

        eMatrix out(rows, columns);

        for(uint8_t row = 0; row < rows; row++) {
            for(uint8_t col = 0; col < columns; col ++) {
                out.arr[row][col] =  arr[row][col] + mat.arr[row][col];
            }
        }
        return out;
    }

    inline eMatrix operator -(const eMatrix &mat) {
        assert(mat.rows == rows && mat.columns == columns);
        eMatrix out(rows, columns);

        for(uint8_t row = 0; row < rows; row++) {
            for(uint8_t col = 0; col < columns; col ++) {
                out.arr[row][col] = arr[row][col] - mat.arr[row][col];
            }
        }
        return out;
    }

    inline eMatrix operator *(const eMatrix &mat) {
//        assert(mat.rows == rows && mat.columns == columns);
        uint8_t M = rows;
        uint8_t N = columns;
        uint8_t P = mat.rows;
        uint8_t Q = mat.columns;

        assert(N == P);

        eMatrix result(M,Q);
        // Perform matrix multiplication
        for (uint8_t m = 0; m < M; ++m) {
            for (uint8_t q = 0; q < Q; ++q) {
                float sum = 0;
                for (uint8_t p = 0; p < P; ++p) {
                    sum += arr[m][p] * mat.arr[p][q];
                }
                result.arr[m][q] = sum;
            }
        }
        return result;
    }

    inline eVector operator *(const eVector &v) {
        assert(v.size == columns);
        uint8_t M = rows;
        uint8_t P = v.size;

        eVector result(M);
        // Perform matrix-vector multiplication
        for (uint8_t m = 0; m < M; ++m) {
            float sum = 0;
            for (uint8_t p = 0; p < P; ++p) {
                sum += arr[m][p] * v.arr[p];
            }
            result.arr[m] = sum;
        }
        return result;
    }

    inline eMatrix T()  {
        eMatrix matT(columns,rows);

        for(uint8_t row = 0; row < rows; row++) {
            for(uint8_t col = 0; col < columns; col++) {
                matT.arr[row][col] = arr[col][row];
            }
        }

        return matT;
    }

    inline eMatrix inv(uint8_t size) {
        eMatrix matInv(rows, columns);
        if(size == 6) {
//        	mat6x6Inverse((Mat*)arr, (Mat*)matInv.arr);
//        	matNxNInverse(arr, matInv.arr);
        	mat6x6GJInverse(arr, matInv.arr);
//        	inverseCholesky6x6(arr, matInv.arr);
        }
        else if(size == 3) {
        	matInv.rows = 3;
        	matInv.columns = 3;
        	mat3x3Inverse(arr, matInv.arr);
        }
        return matInv;
    }

    static inline eMatrix Identity(uint8_t size) {
        eMatrix I(size, size);
        for (uint8_t d = 0; d < size; d++) {
            I.arr[d][d] = 1;
        }
        return I;
    }

    inline eMatrix operator ()(uint8_t head) {
    	assert(head > 0 && head <= rows);
    	if(head == rows) {
    		return *this;
    	}

    	eMatrix headMat = *this;
    	headMat.rows = head;
    	return headMat;
    }

    inline eMatrix operator ()(uint8_t row, uint8_t col) {
    	assert(row > 0 && row <= rows && col > 0 && col <= columns);
    	if(row == rows && col == columns) {
    		return *this;
    	}

    	eMatrix headMat = *this;
    	headMat.rows = row;
    	headMat.columns = col;
    	return headMat;
    }

    inline void resetZero() {
        for(uint8_t row = 0; row < rows; row++) {
            for(uint8_t col = 0; col < columns; col++) {
                arr[row][col] = 0;
            }
        }
    }

    inline void resetDiag(float diag) {
        for(uint8_t row = 0; row < rows; row++) {
            for(uint8_t col = 0; col < columns; col++) {
            	if(row == col) {
            		arr[row][col] = diag;
            	}
            	else {
            		arr[row][col] = 0;
            	}
            }
        }
    }

//    inline diag(uint8_t d[])

private:
    typedef struct {
      float m00, m01, m02, m03, m04, m05;
      float m10, m11, m12, m13, m14, m15;
      float m20, m21, m22, m23, m24, m25;
      float m30, m31, m32, m33, m34, m35;
      float m40, m41, m42, m43, m44, m45;
      float m50, m51, m52, m53, m54, m55;
    }Mat;

    void mat6x6Inverse(Mat* m, Mat* out);

    void matNxNInverse(float mat[MAT_MAX_SIZE][MAT_MAX_SIZE], float out[MAT_MAX_SIZE][MAT_MAX_SIZE]);

    void mat3x3Inverse(float arrIn[MAT_MAX_SIZE][MAT_MAX_SIZE], float arrOut[MAT_MAX_SIZE][MAT_MAX_SIZE]);

    void mat6x6GJInverse(float matrix[MAT_MAX_SIZE][MAT_MAX_SIZE], float inverse[MAT_MAX_SIZE][MAT_MAX_SIZE]);

    void inverseCholesky6x6(float A[MAT_MAX_SIZE][MAT_MAX_SIZE], float invA[MAT_MAX_SIZE][MAT_MAX_SIZE]);


};



#endif /* EKF_EKFMATH_IMATRIX_H_ */
